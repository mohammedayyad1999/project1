/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.ObservableSet;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author Mohammed
 */
public class AccountsController implements Initializable {

    @FXML
    private AnchorPane edit_student_pane;
    @FXML
    private Button set_enroll_cancel;
    @FXML
    private Button set_enroll;
    @FXML
    private ComboBox combo_all_councel_name;
    @FXML
    private Label label_erolled;
    @FXML
    private Button cancel_2;
    @FXML
    private Button add_2;
    @FXML
    private TextField ad_u_name;
    @FXML
    private TextField a_u_password;
    @FXML
    private ComboBox combo_a_u_type;
    @FXML
    private Button add_council;
    @FXML
    private ListView a_u_list;
    @FXML
    private Button remove_selected_council_enrolment;
    @FXML
    private TableColumn tpassword;
    @FXML
    private TableColumn ttype;
    @FXML
    private TableColumn tname;
    @FXML
    private TableView table;

    /**
     * Initializes the controller class.
     */
    database db1=new database();
    @FXML
    private AnchorPane p3;
    @FXML
    private AnchorPane p2;
    @FXML
    private AnchorPane p1;
    @FXML
    private TableColumn tcouncil;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
     tname.setCellValueFactory(new PropertyValueFactory("user_name"));
        ttype.setCellValueFactory(new PropertyValueFactory("type"));
        tpassword.setCellValueFactory(new PropertyValueFactory("password"));
        tcouncil.setCellValueFactory(new PropertyValueFactory("user_council"));
        try {
            table.setItems(FXCollections.observableArrayList(db1.all_users()));
        } catch (SQLException ex) {
            Logger.getLogger(AccountsController.class.getName()).log(Level.SEVERE, null, ex);
        }
        combo_a_u_type.setItems(FXCollections.observableArrayList("مسؤول","متطوع"));
    }    

    @FXML
    private void cancel_2() {
        p1.toFront();
        ad_u_name.clear();
        a_u_password.clear();
        combo_a_u_type.getSelectionModel().clearSelection();
        new_enrollment.clear();
        a_u_list.getItems().clear();
        set_v();
        set_v2();
    }

    ArrayList<String> new_enrollment = new ArrayList();
    boolean edited_new_enrollment=false;

    @FXML
    private void enroll_student(ActionEvent event) throws SQLException {
        

        if (combo_all_councel_name.getValue() != null && new_enrollment.indexOf(combo_all_councel_name.getValue().toString())==-1) {

if(!edited_new_enrollment&&new_enrollment.isEmpty()){
           ArrayList<String> data_ph=db1.all_users_council(ad_u_name.getText());
          for (int i = 0; i < data_ph.size(); i++) {
        
    
            if(!data_ph.get(i).equals("")){    
            new_enrollment.add(data_ph.get(i));
            edited_new_enrollment=true;}
        }}

        
         new_enrollment.add(combo_all_councel_name.getValue().toString());
         a_u_list.setItems(FXCollections.observableArrayList(new_enrollment));

            
            label_erolled.setDisable(true);
            label_erolled.setVisible(false);
             edited_new_enrollment=true;
            p2.toFront();

        } else {
            label_erolled.setDisable(false);
            label_erolled.setVisible(true);
        }
        set_v2();
        combo_all_councel_name.getSelectionModel().clearSelection();
        set_v3();
    }
    

    @FXML
    private void add(ActionEvent event) throws SQLException {
        ArrayList<alldata> all_user=db1.all_users();
         ArrayList<String> u_name=new ArrayList();
         for (int i = 0; i < all_user.size(); i++) {
            u_name.add(all_user.get(i).getUser_name());
        }
         if (u_name.indexOf(ad_u_name.getText())==-1);
        db1.add_user(ad_u_name.getText(), a_u_password.getText(),combo_a_u_type.getValue().toString());
        if (edited_new_enrollment) {

            for (int i = 0; i < new_enrollment.size(); i++) {
                db1.add_user_council(ad_u_name.getText(), new_enrollment.get(i));
            }

        }
         table.setItems(FXCollections.observableArrayList(db1.all_users()));
        cancel_2();
        
    }

    @FXML
    private void add_council(ActionEvent event) throws SQLException {
        combo_all_councel_name.setItems(FXCollections.observableArrayList(db1.all_councel_name()));
        p3.toFront();
    }


    @FXML
    private void add_new_user(ActionEvent event) {
        p1.toFront();
        p2.toFront();
    }

    @FXML
    private void remove_selected_council_enrolment(ActionEvent event) throws SQLException {
        ObservableList<alldata> a=table.getSelectionModel().getSelectedItems();
        db1.delete_user(a.get(0).getUser_name());
        table.setItems(FXCollections.observableArrayList(db1.all_users()));
        set_v();
    }

    @FXML
    private void set_v3() {
        if(combo_all_councel_name.getValue()!=null)
        set_enroll.setDisable(false);
        else
        set_enroll.setDisable(true);

    }

    @FXML
    private void set_v2() {
        if(!ad_u_name.getText().isEmpty()&& !a_u_password.getText().isEmpty() &&combo_a_u_type.getValue()!=null){
            if(combo_a_u_type.getValue().toString().equals("متطوع")){
            if(!a_u_list.getItems().isEmpty())
                add_2.setDisable(false);
            else
                add_2.setDisable(true);
            }
            else if(combo_a_u_type.getValue().toString().equals("مسؤول"))
                add_2.setDisable(false);}
            else
            add_2.setDisable(true);
    }

   

    @FXML
    private void set_v() {
        if(table.getSelectionModel().getSelectedIndex()!=-1)
            remove_selected_council_enrolment.setDisable(false);
        else
            remove_selected_council_enrolment.setDisable(true);
        
    }
    @FXML
    private void cancel_3() {
        p2.toFront();
        
    }

    @FXML
    private void set_v4(ActionEvent event) {
        if (combo_a_u_type.getValue()!=null) {
           if(combo_a_u_type.getValue().toString().equals("مسؤول"))
            add_council.setDisable(true);
        else
            add_council.setDisable(false); 
        }
                set_v2();
                

    }
}
