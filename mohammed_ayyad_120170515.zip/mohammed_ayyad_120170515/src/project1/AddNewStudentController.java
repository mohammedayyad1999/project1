/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;

/**
 * FXML Controller class
 *
 * @author Mohammed
 */
public class AddNewStudentController implements Initializable {

    @FXML
    private Button close;
    @FXML
    private HBox hbox2;
    @FXML
    private TextField t3;
    @FXML
    private TextField t1;
    @FXML
    private HBox hbox1;
    @FXML
    private Button add;
    @FXML
    private Button add_phone_number;
    @FXML
    private Label labelcheck;
    @FXML
    private AnchorPane add_student_pane;

    /**
     * Initializes the controller class.
     */
    database db1 = new database();
    @FXML
    private AnchorPane p1_add_std;
    @FXML
    private Button cancel_2;
    @FXML
    private Button add_new_phone_submit;
    @FXML
    private TextField tf_new_phone;
    @FXML
    private AnchorPane p2_add_phone;
    @FXML
    private ListView list2;
    @FXML
    private Button add_new_council_enrollment;
    @FXML
    private AnchorPane p2_add_enrollment;
    @FXML
    private Button set_enroll_cancel;
    @FXML
    private Button set_enroll;
    @FXML
    private ComboBox all_councel_name;
    @FXML
    private Label label_erolled;
    @FXML
    private ListView list4;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void close() throws SQLException {
        AnchorPane x = (AnchorPane) add_student_pane.getParent();
        for (int i = 0; i < 4; i++) {
            x.getChildren().get(i).setDisable(false);
        }
        x.getChildren().remove(4);
        AnchorPane z = (AnchorPane) x.getChildren().get(3);
        TableView tb = (TableView) z.getChildren().get(0);
        tb.setItems(FXCollections.observableArrayList(db1.allstudent("%")));
    }

    @FXML
    private void setvisable() {
        String x[]=t1.getText().split("\\s+");
        if (x.length==4&&!t1.getText().isEmpty() && !t3.getText().isEmpty()) {
            add.setDisable(false);
            t1.setStyle("-fx-border-color:null");
            labelcheck.setDisable(true);
            labelcheck.setVisible(false);
        } else {
            if(x.length!=4){
            t1.setStyle("-fx-border-color:red");
            labelcheck.setDisable(false);
            labelcheck.setVisible(true);}
            else{
                t1.setStyle("-fx-border-color:null");
            labelcheck.setDisable(true);
            labelcheck.setVisible(false);}
            add.setDisable(true);
        }
    }

    @FXML
    private void chcek(KeyEvent event) {
    }

    @FXML
    private void add(ActionEvent event) throws SQLException {

        db1.add_student(t1.getText(), t3.getText());
        if (true) {
            for (int i = 0; i < new_enrollment.size(); i++) {
                db1.add_student_enrollment(t1.getText(), new_enrollment.get(i));
            }

        }
        if (edited_new_phone) {

            for (int i = 0; i < new_phones.size(); i++) {
                db1.add_new_std_phone(t1.getText(), new_phones.get(i));
            }

        }
        close();
    }

    @FXML
    private void add_phone_number(ActionEvent event) {
        p1_add_std.setDisable(true);
        p2_add_phone.setDisable(false);
        p2_add_phone.toFront();
        tf_new_phone.clear();
    }

    @FXML
    private void cancel_2() {

        p2_add_phone.setDisable(true);
        p1_add_std.setDisable(false);
        p1_add_std.toFront();
    }

    ArrayList<String> new_phones = new ArrayList();
    boolean edited_new_phone = false;

    @FXML
    private void add_new_phone_submit(ActionEvent event) throws SQLException {
        if (!edited_new_phone && new_phones.isEmpty()) {
            ArrayList<String> data_ph = db1.get_std_phones(t1.getText());
            for (String phone : data_ph) {
                new_phones.add(phone);
                edited_new_phone = true;
            }
        }

        new_phones.add(tf_new_phone.getText());

        list2.setItems(FXCollections.observableArrayList(new_phones));
        cancel_2();

    }

    @FXML
    private void add_new_council_enrollment(ActionEvent event) throws SQLException {
        p1_add_std.setDisable(true);
        p2_add_enrollment.setDisable(false);
        p2_add_enrollment.toFront();
        all_councel_name.setItems(FXCollections.observableArrayList(db1.all_councel_name()));
    }

    ArrayList<String> new_enrollment = new ArrayList();
    boolean edited_new_enrollment = false;

    @FXML
    private void enroll_student(ActionEvent event) throws SQLException {

        if (all_councel_name.getValue() != null && new_enrollment.indexOf(all_councel_name.getValue().toString()) == -1) {
            if (!edited_new_enrollment && new_enrollment.isEmpty()) {
                edited_new_phone = true;
            }

            new_enrollment.add(all_councel_name.getValue().toString());
            list4.setItems(FXCollections.observableArrayList(new_enrollment));

            label_erolled.setDisable(true);
            label_erolled.setVisible(false);
            cancel_2();

        } else {
            label_erolled.setDisable(false);
            label_erolled.setVisible(true);
        }
    }

}
