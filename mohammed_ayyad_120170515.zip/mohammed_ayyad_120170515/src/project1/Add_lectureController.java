/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;

/**
 * FXML Controller class
 *
 * @author Mohammed
 */
public class Add_lectureController implements Initializable {
    static String council_name;

    @FXML
    private AnchorPane p1_add_std;
    @FXML
    private Button close;
    @FXML
    private HBox hbox2;
    @FXML
    private ListView list3;
    @FXML
    private TextField t2;
    @FXML
    private TextField t1;
    @FXML
    private HBox hbox1;
    @FXML
    private Button add;
    @FXML
    private Button add_takes;
    @FXML
    private AnchorPane p2_add_takes;
    @FXML
    private TableView table;
    @FXML
    private TableColumn std_takes;
    @FXML
    private TableColumn std_name;
    @FXML
    private Button add_2;
    @FXML
    private Button cancel_2;

    /**
     * Initializes the controller class.
     */
    database db1=new database();
    @FXML
    private AnchorPane add_lec_pane;
    @FXML
    private CheckBox select_all;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        std_name.setCellValueFactory(new PropertyValueFactory("Std_name"));
        std_takes.setCellValueFactory(new PropertyValueFactory("Ss"));
        try {
            table.setItems(FXCollections.observableArrayList(db1.council_student(council_name, 0)));
         
            
        } catch (SQLException ex) {
            Logger.getLogger(Add_lectureController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    

    @FXML
    private void close() {         
        AnchorPane x = (AnchorPane) add_lec_pane.getParent();
        for (int i = 0; i < 4; i++) {
            x.getChildren().get(i).setDisable(false);
        }
        x.getChildren().remove(4);
        AnchorPane z = (AnchorPane) x.getChildren().get(3);
        TableView tb = (TableView) z.getChildren().get(0);
        try {
            tb.setItems(FXCollections.observableArrayList(db1.council_lecture(council_name,"%")));
            tb.getSelectionModel().selectLast();
        } catch (SQLException ex) {
            Logger.getLogger(Add_lectureController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void setvisable(KeyEvent event) {
        if (!t1.getText().isEmpty()&&!t2.getText().isEmpty()) {
            add.setDisable(false);
        }
        else
            add.setDisable(true);

    }

    @FXML
    private void add(ActionEvent event) throws SQLException {
        if (!t1.getText().isEmpty()&&!t2.getText().isEmpty()) {
            db1.add_lecture(council_name,t1.getText() ,t2.getText() );
            if(!takes.isEmpty()){
                for (int i = 0; i < takes.size(); i++) {
                    int num=db1.lec_num(council_name);
                    db1.add_takes(takes.get(i), council_name,num);
                }
            }
            
            close();
        }
        
    }

    @FXML
    private void add_takes(ActionEvent event) {
        p2_add_takes.toFront();
    }

   
    
    ArrayList<String> takes=new ArrayList();
    @FXML
    private void add_2(ActionEvent event) {
        ObservableList<alldata> qq=table.getItems();
      for (int i = 0; i < table.getItems().size(); i++) {
          
          if(qq.get(i).getChecked()==1){
              if(takes.indexOf(qq.get(i).getStd_name())==-1){
                  takes.add(qq.get(i).getStd_name());
              
            System.out.println(qq.get(i).getStd_name()+" "+qq.get(i).getChecked());
              }
          }
          else if(qq.get(i).getChecked()==0){
              if(takes.indexOf(qq.get(i).getStd_name())!=-1){
                  takes.remove(qq.get(i).getStd_name());
              
            System.out.println(qq.get(i).getStd_name()+" "+qq.get(i).getChecked());
              }
          }
        }
      list3.setItems(FXCollections.observableArrayList(takes));
      cancel2();
    }

    @FXML
    private void cancel2() {
        p1_add_std.toFront();
    }

    @FXML
    private void select_all(ActionEvent event) {
    }
    
}
