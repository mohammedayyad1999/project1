/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;

/**
 * FXML Controller class
 *
 * @author Mohammed
 */
public class EditStudentController implements Initializable {

    static String std_name = "amir";
    static String std_area = "ziton";
    static int selected;
    @FXML
    private Button save;
    @FXML
    private Button close;
    @FXML
    private HBox hbox2;
    @FXML
    private TextField t3;
    @FXML
    private TextField t1;
    @FXML
    private HBox hbox1;
    @FXML
    private AnchorPane p2_add_enrollment;
    @FXML
    private Button set_enroll_cancel;
    @FXML
    private Button set_enroll;
    @FXML
    private ComboBox all_councel_name;
    @FXML
    private AnchorPane p3_add_phone;
    @FXML
    private Button cancel_2;
    @FXML
    private Button add_new_phone_submit;
    @FXML
    private TextField tf_new_phone;
    @FXML
    private AnchorPane p1_std_edit;
    @FXML
    private ComboBox combo_all_enrolled_council;
    @FXML
    private ComboBox combo_phone_num;
    @FXML
    private Button add_new_council_enrollment;
    @FXML
    private Button remove_selected_council_enrolment;
    @FXML
    private Button add_new_phone;
    @FXML
    private Button remove_selected_phone;
    boolean enrolledited=false;
    boolean edited_new_phone=false;
    boolean edited_new_phone2=false;


    /**
     * Initializes the controller class.
     */
    database db1 = new database();
    @FXML
    private AnchorPane edit_student_pane;
    @FXML
    private Label label_erolled;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        t1.setText(std_name);
        t3.setText(std_area);
        
        try {
            combo_phone_num.setItems(FXCollections.observableArrayList(db1.get_std_phones(t1.getText())));

            String[] a = db1.all_std_council(t1.getText()).split("\n ");
            combo_all_enrolled_council.setItems(FXCollections.observableArrayList(a));
        } catch (SQLException ex) {
            Logger.getLogger(EditStudentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        if(!edited_new_enrollment&&new_enrollment.isEmpty()){
            try {
                String [] data_ph = db1.all_std_council(t1.getText()).trim().split("\n");
                for (String council : data_ph) {
                    if(!council.trim().equals("")){
                        new_enrollment.add(council.trim());
                        edited_new_enrollment=true;}
                }   } catch (SQLException ex) {
                Logger.getLogger(EditStudentController.class.getName()).log(Level.SEVERE, null, ex);
            }
            
}
        if(!edited_new_phone&&new_phones.isEmpty()){
            try {
                ArrayList<String> data_ph = db1.get_std_phones(t1.getText());
                for (String phone : data_ph) {
                    new_phones.add(phone);
                    
                    
                edited_new_phone=true;
                }
            } catch (SQLException ex) {
                Logger.getLogger(EditStudentController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @FXML
    private void save(ActionEvent event) throws SQLException {
        if (!t3.getText().equals(std_area)) {
            db1.update_student_area(t1.getText(), t3.getText());
            std_area = t3.getText();
            
            setvisable();
        }
        
        if (edited_new_phone) {
            db1.remove__all_std_phone(t1.getText());
            for (int i = 0; i < new_phones.size(); i++) {
                db1.add_new_std_phone(t1.getText(), new_phones.get(i));
                
            }
               setvisable();
}
if (enrolledited){
             ArrayList<String> enroll=new ArrayList();
             ArrayList<String> remove=new ArrayList();
             ArrayList<String> enrolled = db1.all_std_council_arraylist(t1.getText());
             for(String council:enrolled){
                 if (new_enrollment.indexOf(council)==-1) {
                     remove.add(council);
                     
                 }
             }
             
             for(String council:new_enrollment){
                 if (enrolled.indexOf(council)==-1) {
                     enroll.add(council);
                    
                 }
             }
             
             for (int i = 0; i < remove.size(); i++) {
                 db1.remove_student_enrollment(t1.getText(), remove.get(i));
             }
             for (int i = 0; i < enroll.size(); i++) {
                 db1.add_student_enrollment(t1.getText(), enroll.get(i));
             }
             
         }

close();
        
         

    }

    @FXML
    private void close() throws SQLException {
        AnchorPane x = (AnchorPane) edit_student_pane.getParent();
        for (int i = 0; i < 4; i++) {
            x.getChildren().get(i).setDisable(false);
        }
        x.getChildren().remove(4);
        AnchorPane z = (AnchorPane) x.getChildren().get(3);
        TableView tb = (TableView) z.getChildren().get(0);
        tb.setItems(FXCollections.observableArrayList(db1.allstudent("%")));
        tb.getSelectionModel().select(selected);
    }

    @FXML
    private void setvisable() {
        if (!t3.getText().equals(std_area)) {
            save.setDisable(false);
        } else {
            save.setDisable(true);
        }

    }

    @FXML
    private void add_new_council_enrollment(ActionEvent event) throws SQLException {
        p1_std_edit.setDisable(true);
        p2_add_enrollment.setDisable(false);
        p2_add_enrollment.toFront();
        all_councel_name.setItems(FXCollections.observableArrayList(db1.all_councel_name()));

    }

    @FXML
    private void remove_selected_council_enrolment(ActionEvent event) throws SQLException {
        ButtonType ok = new ButtonType("حذف", ButtonBar.ButtonData.OK_DONE.LEFT);

        ButtonType close = new ButtonType("الغاء", ButtonBar.ButtonData.CANCEL_CLOSE.RIGHT);

        Alert alert = new Alert(AlertType.WARNING, "تحذير!!!\nسوف تقوم بحذف انتماء الطالب لهذا المجلس وسجلات حضوره لمحاضرات هذا المجلس ", close, ok);
        alert.setTitle("Date format warning");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ok) {

if(!edited_new_enrollment&&new_enrollment.isEmpty()){
             String [] data_ph = db1.all_std_council(t1.getText()).trim().split("\n");
            for (String council : data_ph) {
            if(!council.trim().equals("")){    
            new_enrollment.add(council.trim());
            edited_new_phone=true;}
        }}
new_enrollment.remove(combo_all_enrolled_council.getValue().toString());
 combo_all_enrolled_council.setItems(FXCollections.observableArrayList(new_enrollment));
 enrolledited=true;
 save.setDisable(false);
 remove_selected_council_enrolment.setDisable(true);

        } else {
        }

    }

    @FXML
    private void add_new_phone(ActionEvent event) {
        p1_std_edit.setDisable(true);
        p3_add_phone.setDisable(false);
        p3_add_phone.toFront();
        tf_new_phone.clear();
   }

    @FXML
    private void remove_selected_phone(ActionEvent event) throws SQLException {
//        db1.remove_phone(combo_phone_num.getValue().toString());
//        combo_phone_num.setItems(FXCollections.observableArrayList(db1.get_std_phones(t1.getText())));
//        remove_selected_phone.setDisable(true);
if(!edited_new_phone&&new_phones.isEmpty()){
            ArrayList<String> data_ph = db1.get_std_phones(t1.getText());
            for (String phone : data_ph) {
            new_phones.add(phone);
            edited_new_phone=true;
        }}
new_phones.remove(combo_phone_num.getValue().toString());
 combo_phone_num.setItems(FXCollections.observableArrayList(new_phones));
 save.setDisable(false);
 remove_selected_phone.setDisable(true);
    }

    @FXML
    private void cancel_2() {
        p2_add_enrollment.setDisable(true);
        p3_add_phone.setDisable(true);
        p1_std_edit.setDisable(false);
        p1_std_edit.toFront();
    }

    ArrayList<String> new_phones = new ArrayList();
    

    @FXML
    private void add_new_phone_submit(ActionEvent event) throws SQLException {
//        db1.add_new_std_phone(t1.getText(),tf_new_phone.getText());
//        combo_phone_num.setItems(FXCollections.observableArrayList(db1.get_std_phones(t1.getText())));
      
        if(!edited_new_phone&&new_phones.isEmpty()){
            ArrayList<String> data_ph = db1.get_std_phones(t1.getText());
            for (String phone : data_ph) {
            new_phones.add(phone);
            
            
        }
            edited_new_phone=true;
        }
        
        new_phones.add(tf_new_phone.getText());
       
        combo_phone_num.setItems(FXCollections.observableArrayList(new_phones));
        edited_new_phone2=true;
        save.setDisable(false);
        cancel_2();

    }

    @FXML
    private void set_remove_councel_enable(ActionEvent event) {
        if (combo_all_enrolled_council.getValue() != null && !combo_all_enrolled_council.getValue().toString().trim().equals("")) {
            remove_selected_council_enrolment.setDisable(false);
        }

    }

    @FXML
    private void set_remove_phone_enable(ActionEvent event) {
        remove_selected_phone.setDisable(false);

    }
    
    
    ArrayList<String> new_enrollment = new ArrayList();
    boolean edited_new_enrollment=false;

    @FXML
    private void enroll_student(ActionEvent event) throws SQLException {
        

        if (all_councel_name.getValue() != null && new_enrollment.indexOf(all_councel_name.getValue().toString())==-1) {

//            db1.add_student_enrollment(t1.getText(), all_councel_name.getValue().toString());
//            String[] a = db1.all_std_council(t1.getText()).split("\n ");
//            combo_all_enrolled_council.setItems(FXCollections.observableArrayList(a));
if(!edited_new_enrollment&&new_enrollment.isEmpty()){
           String [] data_ph = db1.all_std_council(t1.getText()).trim().split("\n");
            for (String council : data_ph) {
            if(!council.trim().equals("")){    
            new_enrollment.add(council.trim());
            edited_new_enrollment=true;}
        }}

        
         new_enrollment.add(all_councel_name.getValue().toString());
combo_all_enrolled_council.setItems(FXCollections.observableArrayList(new_enrollment));

            if (combo_all_enrolled_council.getValue() == null) {
                remove_selected_council_enrolment.setDisable(true);
            }
            label_erolled.setDisable(true);
            label_erolled.setVisible(false);
            cancel_2();
             enrolledited=true;

            save.setDisable(false);
        } else {
            label_erolled.setDisable(false);
            label_erolled.setVisible(true);
        }
    }
    
    

}
