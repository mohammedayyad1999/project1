/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import static project1.Add_lectureController.council_name;
import static project1.EditStudentController.selected;
import static project1.EditStudentController.std_name;

/**
 * FXML Controller class
 *
 * @author Mohammed
 */
public class Edit_lectureController implements Initializable {

    static int lec_num;
    static String council_name;
    static int selected = 0;
    static String topic;
    static String place;
    static String takes_count;

    @FXML
    private Button can_2;
    @FXML
    private Button set_enroll;
    @FXML
    private TableView table;
    @FXML
    private TableColumn t_takes;
    @FXML
    private TableColumn tstd_name;
    @FXML
    private CheckBox select_all;
    @FXML
    private AnchorPane p1_lec_edit;
    @FXML
    private Button save;
    @FXML
    private Button close;
    @FXML
    private HBox hbox2;
    @FXML
    private TextField t3;
    @FXML
    private TextField t2;
    @FXML
    private TextField t1;
    @FXML
    private HBox hbox1;
    @FXML
    private Button edit_takes;

    /**
     * Initializes the controller class.
     */
    database db1 = new database();
    @FXML
    private AnchorPane p2_edit_takes;
    @FXML
    private AnchorPane edit_lec_pane;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        t1.setText(topic);
        t2.setText(place);
        t3.setText(takes_count);
        try {
            table.setItems(FXCollections.observableArrayList(db1.lec_takes(council_name, lec_num)));
        } catch (SQLException ex) {
            Logger.getLogger(Edit_lectureController.class.getName()).log(Level.SEVERE, null, ex);
        }
        tstd_name.setCellValueFactory(new PropertyValueFactory("Std_name"));
        t_takes.setCellValueFactory(new PropertyValueFactory("Ss"));
    }

    @FXML
    private void cancel_2() {
        p1_lec_edit.toFront();
    }

    @FXML
    private void select_all(ActionEvent event) {
    }

    @FXML
    private void save(ActionEvent event) throws SQLException {
        if (!t1.getText().equals(topic) || !t2.getText().equals(place)) {
            db1.update_lecture(council_name, lec_num, t1.getText(), t2.getText());
        }
        if (ed) {
            db1.delete_takes(council_name, lec_num);
            for (int i = 0; i < takes.size(); i++) {
                db1.add_takes(takes.get(i), council_name, lec_num);
            }
        }
        close();

    }

    @FXML
    private void close() throws SQLException {
        AnchorPane x = (AnchorPane) edit_lec_pane.getParent();
        for (int i = 0; i < 4; i++) {
            x.getChildren().get(i).setDisable(false);
        }
        x.getChildren().remove(4);
        AnchorPane z = (AnchorPane) x.getChildren().get(3);
        TableView tb = (TableView) z.getChildren().get(0);
        tb.setItems(FXCollections.observableArrayList(db1.council_lecture(council_name, "%")));
        tb.getSelectionModel().select(selected);
    }

    @FXML
    private void setvisable(KeyEvent event) {
    }

    @FXML
    private void edit_takes(ActionEvent event) {
        p2_edit_takes.toFront();
    }

    ArrayList<String> takes = new ArrayList();
    boolean ed=false;

    @FXML
    private void add_2(ActionEvent event) {
        ObservableList<alldata> qq = table.getItems();
        for (int i = 0; i < table.getItems().size(); i++) {

            if (qq.get(i).getChecked() == 1) {
                if (takes.indexOf(qq.get(i).getStd_name()) == -1) {
                    takes.add(qq.get(i).getStd_name());

                    //System.out.println(qq.get(i).getStd_name()+" "+qq.get(i).getChecked());
                }
            } else if (!qq.get(i).getSs().isSelected()) {
                if (takes.indexOf(qq.get(i).getStd_name()) != -1) {
                    takes.remove(qq.get(i).getStd_name());

                    //System.out.println(qq.get(i).getStd_name()+" "+qq.get(i).getChecked());
                }
            }
            t3.setText("" + (takes.size()));
            

        }
ed=true;
        cancel_2();
    }




ArrayList<String> beftakes = new ArrayList();
    boolean befed=false;

    @FXML
    public  void befadd_2() throws SQLException {
        
        ArrayList<alldata> qq=db1.lec_takes(council_name, lec_num);
        for (int i = 0; i < qq.size(); i++) {

            if (qq.get(i).getChecked() == 1) {
                if (beftakes.indexOf(qq.get(i).getStd_name()) == -1) {
                    beftakes.add(qq.get(i).getStd_name());

                    //System.out.println(qq.get(i).getStd_name()+" "+qq.get(i).getChecked());
                }
            } else if (!qq.get(i).getSs().isSelected()) {
                if (beftakes.indexOf(qq.get(i).getStd_name()) != -1) {
                    beftakes.remove(qq.get(i).getStd_name());

                    //System.out.println(qq.get(i).getStd_name()+" "+qq.get(i).getChecked());
                }
            }
            
            

        }

if (true) {
            db1.delete_takes(council_name, lec_num);
            for (int i = 0; i < beftakes.size(); i++) {
                db1.add_takes(beftakes.get(i), council_name, lec_num);
            }
        }
        
    }
}
