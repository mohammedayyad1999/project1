/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author Mohammed
 */
public class LectureController implements Initializable {
    static int vtype=0;
    static String user_name="ahmed2";

    @FXML
    private TableView table;
    @FXML
    private TableColumn tstd_num;
    @FXML
    private TableColumn ttopic;
    @FXML
    private TableColumn tlec_number;
    @FXML
    private TextField searchtext;
    @FXML
    private Button lec_setting;
    @FXML
    private Button add_lec;
    @FXML
    private Button trash;
    @FXML
    private Button delete_lec;
    @FXML
    private ComboBox chose_councel;

    /**
     * Initializes the controller class.
     */
    database db1 = new database();
    @FXML
    private AnchorPane lec_pane;
    @FXML
    private TableColumn tplace;

    @Override

    public void initialize(URL url, ResourceBundle rb) {
        
        if (vtype==0){
        try {
            chose_councel.setItems(FXCollections.observableArrayList(db1.all_councel_name()));
        } catch (SQLException ex) {
            Logger.getLogger(LectureController.class.getName()).log(Level.SEVERE, null, ex);
        }}
        else if (vtype==1){
            try {
                chose_councel.setItems(FXCollections.observableArrayList(db1.v_councel_name(user_name)));
            } catch (SQLException ex) {
                Logger.getLogger(LectureController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        tlec_number.setCellValueFactory(new PropertyValueFactory("Lec_num"));
        ttopic.setCellValueFactory(new PropertyValueFactory("Lec_name"));
        tplace.setCellValueFactory(new PropertyValueFactory("Lec_plase"));
        tstd_num.setCellValueFactory(new PropertyValueFactory("Takes_num"));
    }

    @FXML
    private void setvisable() {
        if (table.getSelectionModel().getSelectedIndex() != -1) {
            lec_setting.setDisable(false);
            delete_lec.setDisable(false);
        } else {
            lec_setting.setDisable(true);
            delete_lec.setDisable(true);
        }
    }

    @FXML
    private void saerch() throws SQLException {
        if (!searchtext.getText().equals("")) {
            table.setItems(FXCollections.observableArrayList(db1.council_lecture(chose_councel.getValue().toString(), "%" + searchtext.getText() + "%")));
        } else {
            table.setItems(FXCollections.observableArrayList(db1.council_lecture(chose_councel.getValue().toString(), "%")));
        }
    }

    @FXML
    private void lec_setting(ActionEvent event) {
        AnchorPane anchorpane = (AnchorPane) lec_pane.getParent();
        if (table.getSelectionModel().getSelectedIndex() != -1) {

            ObservableList<alldata> selected_row = table.getSelectionModel().getSelectedItems();
            ObservableList<alldata> sel_row = table.getSelectionModel().getSelectedItems();
            Edit_lectureController.lec_num = Integer.parseInt(sel_row.get(0).getLec_num());
            Edit_lectureController.topic = sel_row.get(0).getLec_name();
            Edit_lectureController.place = sel_row.get(0).getLec_plase();
            Edit_lectureController.takes_count = sel_row.get(0).getTakes_num();
            Edit_lectureController.council_name = chose_councel.getValue().toString();

            try {
                Parent zz = FXMLLoader.load(getClass().getResource("/project1/edit_lecture.fxml"));
                AnchorPane.setTopAnchor(zz, 85.0);
                AnchorPane.setBottomAnchor(zz, 54.0);
                AnchorPane.setLeftAnchor(zz, 206.0);
                AnchorPane.setRightAnchor(zz, 134.0);
                anchorpane.getChildren().add(zz);

            } catch (IOException ex) {
                Logger.getLogger(homeStartController.class.getName()).log(Level.SEVERE, null, ex);
            }
            for (int i = 0; i < 4; i++) {
                anchorpane.getChildren().get(i).setDisable(true);
            }
            Edit_lectureController.selected = table.getSelectionModel().getSelectedIndex();
        }
    }

    @FXML
    private void add_new_lec(ActionEvent event) {
        Add_lectureController.council_name = chose_councel.getValue().toString();
        AnchorPane anchorpane = (AnchorPane) lec_pane.getParent();
        try {
            Parent zz = FXMLLoader.load(getClass().getResource("/project1/add_lecture.fxml"));
            AnchorPane.setTopAnchor(zz, 85.0);
            AnchorPane.setBottomAnchor(zz, 54.0);
            AnchorPane.setLeftAnchor(zz, 206.0);
            AnchorPane.setRightAnchor(zz, 134.0);
            anchorpane.getChildren().add(zz);

        } catch (IOException ex) {
            Logger.getLogger(homeStartController.class.getName()).log(Level.SEVERE, null, ex);
        }
        for (int i = 0; i < 4; i++) {
            anchorpane.getChildren().get(i).setDisable(true);
        }

    }

    @FXML
    private void clear(ActionEvent event) throws SQLException {
        searchtext.setText("");
        saerch();
        setvisable();
    }

    @FXML
    private void delete_selected_lec(ActionEvent event) throws SQLException {
        ButtonType ok = new ButtonType("حذف", ButtonBar.ButtonData.OK_DONE.LEFT);

        ButtonType close = new ButtonType("الغاء", ButtonBar.ButtonData.CANCEL_CLOSE.RIGHT);

        Alert alert = new Alert(Alert.AlertType.WARNING, "تحذير!!!\nسوف تقوم بحذف المحاضرة و جميع بياناتها بلاضافة لسجل الحضور", close, ok);
        alert.setTitle("Date format warning");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ok) {
            ObservableList<alldata> selected_row = table.getSelectionModel().getSelectedItems();
            db1.delete_lecture(chose_councel.getValue().toString(),Integer.parseInt(selected_row.get(0).getLec_num()));
            saerch();
            setvisable();
        } else {
        }

    }

    @FXML
    private void chose_councel(ActionEvent event) throws SQLException, IOException {
        Edit_lectureController e=new Edit_lectureController();
                
              ArrayList<alldata> a=db1.council_lecture(chose_councel.getValue().toString(), "%");  
        for (int i = 0; i < a.size(); i++) {
            
            Edit_lectureController.lec_num = Integer.parseInt(a.get(i).getLec_num());
            Edit_lectureController.topic = a.get(i).getLec_name();
            Edit_lectureController.place = a.get(i).getLec_plase();
            Edit_lectureController.takes_count = a.get(i).getTakes_num();
            Edit_lectureController.council_name = chose_councel.getValue().toString();
            e.befadd_2();
        }
        table.setDisable(false);
        trash.setDisable(false);
        searchtext.setDisable(false);
        table.setItems(FXCollections.observableArrayList(db1.council_lecture(chose_councel.getValue().toString(), "%")));
        add_lec.setDisable(false);
        
            
        
    }

}
