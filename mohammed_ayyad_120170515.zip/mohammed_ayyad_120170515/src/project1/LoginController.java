/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Line;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Mohammed
 */
public class LoginController implements Initializable {

    @FXML
    private TextField user_name;
    @FXML
    private Line userline;
    @FXML
    private Line passwordline;
    @FXML
    private PasswordField password;
    @FXML
    private Button login;

    /**
     * Initializes the controller class.
     */
    database db1=new database();
    @FXML
    private Label labelwrong;
    @FXML
    private AnchorPane login_pane;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void exit(MouseEvent event) {
        System.exit(0);
    }

    @FXML
    private void active(MouseEvent event) {
        userline.setStyle("-fx-stroke: #00FF4E;");
        passwordline.setStyle("-fx-stroke: white;");
    }

    @FXML
    private void active2(MouseEvent event) {
        passwordline.setStyle("-fx-stroke: #00FF4E;");
        userline.setStyle("-fx-stroke: white;");
    }

    @FXML
    private void login(ActionEvent event) throws SQLException, IOException {
        ArrayList<String> user=db1.checkuser(user_name.getText());
        if(user.get(0).equals("1")){
            if (password.getText().equals(user.get(2))) {
                labelwrong.setVisible(false);
                if (user.get(3).equals("m")) {
                    
            Parent fxmlLoader = FXMLLoader.load(getClass().getResource("/project1/hamestart.fxml"));
            Scene scene = new Scene(fxmlLoader);
            Stage stage = new Stage();
            stage.setTitle("");
            stage.setScene(scene);
            stage.show();
            LectureController.vtype=0;
            TakesController.vtype=0;
            login_pane.getScene().getWindow().hide();
                }
                else if (user.get(3).equals("v")) {
                    V_studentController.vname=user.get(1);
                    LectureController.user_name=user.get(1);
                    LectureController.vtype=1;
                    TakesController.user_name=user.get(1);
                    TakesController.vtype=1;
                    Parent fxmlLoader = FXMLLoader.load(getClass().getResource("/project1/userui.fxml"));
            Scene scene = new Scene(fxmlLoader);
            Stage stage = new Stage();
            stage.setTitle("");
            stage.setScene(scene);
            stage.show();
            login_pane.getScene().getWindow().hide();
                }
            }
            else{
                labelwrong.setText("خطأ في كلمة المرور");
                labelwrong.setVisible(true);
            }
            
 
        }
        else{
            labelwrong.setText("خطأ في اسم المستخدم");
            labelwrong.setVisible(true);}
           
    }
    
}
