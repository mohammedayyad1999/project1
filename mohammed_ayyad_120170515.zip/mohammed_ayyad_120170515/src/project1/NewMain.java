/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 *
 * @author Mohammed
 */
public class NewMain extends Application {
static Stage stage1;
            
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
        

    }
database db1= new database();
    @Override
    public void start(Stage stage) throws Exception {
        try {
            db1.conncet();
            try {
                db1.set_schema("religion_council");
            } catch (Exception ex) {
                Logger.getLogger(councilController.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (SQLException ex) {
            Logger.getLogger(councilController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    Parent  root =FXMLLoader.load(getClass().getResource("/project1/login.fxml"));
    Scene pane =new Scene(root);
    stage.setScene(pane);
    stage.initStyle(StageStyle.UNDECORATED);
    stage.setTitle(" ");
    stage1=stage;
    stage.show();
    
}
    
}
