/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.ObservableSet;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author Mohammed
 */
public class StudentController implements Initializable {

    @FXML
    private TableView table;
    @FXML
    private TableColumn std_councel_num;
    @FXML
    private TableColumn std_area;
    @FXML
    private TableColumn std_phone;
    @FXML
    private TableColumn std_name;
    @FXML
    private TextField searchtext;
    @FXML
    private Button trash;

    /**
     * Initializes the controller class.
     */
    database db1 = new database();
    @FXML
    private AnchorPane student_pane;
    @FXML
    private Button std_setting;
    @FXML
    private Button add_std;
    @FXML
    private Button delete_std;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        std_name.setCellValueFactory(new PropertyValueFactory("Std_name"));
        std_phone.setCellValueFactory(new PropertyValueFactory("Std_phone"));
        std_area.setCellValueFactory(new PropertyValueFactory("Std_area"));
        std_councel_num.setCellValueFactory(new PropertyValueFactory("Std_councel_count"));

        try {
            table.setItems(FXCollections.observableArrayList(db1.allstudent("%")));
        } catch (SQLException ex) {
            Logger.getLogger(StudentController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @FXML
    private void setvisable() {
        if (table.getSelectionModel().getSelectedIndex() != -1) {
            std_setting.setDisable(false);
            delete_std.setDisable(false);
        } else {
            std_setting.setDisable(true);
            delete_std.setDisable(true);
        }

    }

    @FXML
    private void saerch() throws SQLException {
        if (!searchtext.getText().equals("")) {
            table.setItems(FXCollections.observableArrayList(db1.allstudent("%" + searchtext.getText() + "%")));
        } else {
            table.setItems(FXCollections.observableArrayList(db1.allstudent("%")));
        }

    }

    @FXML
    private void setting(ActionEvent event) {

        AnchorPane anchorpane = (AnchorPane) student_pane.getParent();
        if (table.getSelectionModel().getSelectedIndex() != -1) {

            ObservableList<alldata> selected_row = table.getSelectionModel().getSelectedItems();
            System.out.println(selected_row.get(0).getCouncil_nsme() + "/n" + selected_row.get(0).getInstructor());
            ObservableList<alldata> sel_row = table.getSelectionModel().getSelectedItems();
            EditStudentController.std_name = sel_row.get(0).getStd_name();
            EditStudentController.std_area = sel_row.get(0).getStd_area();

            try {
                Parent zz = FXMLLoader.load(getClass().getResource("/project1/EditStudent.fxml"));
                AnchorPane.setTopAnchor(zz, 85.0);
                AnchorPane.setBottomAnchor(zz, 54.0);
                AnchorPane.setLeftAnchor(zz, 206.0);
                AnchorPane.setRightAnchor(zz, 134.0);
                anchorpane.getChildren().add(zz);

            } catch (IOException ex) {
                Logger.getLogger(homeStartController.class.getName()).log(Level.SEVERE, null, ex);
            }
            for (int i = 0; i < 4; i++) {
                anchorpane.getChildren().get(i).setDisable(true);
            }
            EditStudentController.selected = table.getSelectionModel().getSelectedIndex();
        }
    }

    @FXML
    private void add_new(ActionEvent event) {
        AnchorPane anchorpane = (AnchorPane) student_pane.getParent();
        try {
            Parent zz = FXMLLoader.load(getClass().getResource("/project1/addNewStudent.fxml"));
            AnchorPane.setTopAnchor(zz, 85.0);
            AnchorPane.setBottomAnchor(zz, 54.0);
            AnchorPane.setLeftAnchor(zz, 206.0);
            AnchorPane.setRightAnchor(zz, 134.0);
            anchorpane.getChildren().add(zz);

        } catch (IOException ex) {
            Logger.getLogger(homeStartController.class.getName()).log(Level.SEVERE, null, ex);
        }
        for (int i = 0; i < 4; i++) {
            anchorpane.getChildren().get(i).setDisable(true);
        }

    }

    @FXML
    private void clear(ActionEvent event) throws SQLException {
        searchtext.setText("");
        saerch();
        setvisable();
    }

    @FXML
    private void delete_selected(ActionEvent event) throws SQLException {
        ButtonType ok = new ButtonType("حذف", ButtonBar.ButtonData.OK_DONE.LEFT);

        ButtonType close = new ButtonType("الغاء", ButtonBar.ButtonData.CANCEL_CLOSE.RIGHT);

        Alert alert = new Alert(AlertType.WARNING, "تحذير!!!\nسوف تقوم بحذف الطالب و جميع بياناته بلاضافة لسجالات حضوره وسجلات انتماءة لمجاس العلم", close, ok);
        alert.setTitle("Date format warning");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ok) {
            ObservableList<alldata> selected_row = table.getSelectionModel().getSelectedItems();
            db1.delete_student(selected_row.get(0).getStd_name());
            saerch();
            setvisable();
        } else {
        }

    }

}
