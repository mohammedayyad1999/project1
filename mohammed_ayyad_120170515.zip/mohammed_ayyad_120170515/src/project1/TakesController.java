/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.Property;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import static project1.Edit_lectureController.council_name;
import static project1.LectureController.vtype;

/**
 * FXML Controller class
 *
 * @author Mohammed
 */
public class TakesController implements Initializable {

    static int vtype = 0;
    static String user_name = "ahmed2";

    @FXML
    private AnchorPane p2_std_takes;
    @FXML
    private Button set_enroll_cancel;
    @FXML
    private ComboBox chose_std_name;
    @FXML
    private TableColumn ttakes;
    @FXML
    private TableColumn t_lec_topic;
    @FXML
    private TableColumn t_lec_num;
    @FXML
    private ComboBox chose_council;
    @FXML
    private Button std_takes;
    @FXML
    private Button std_more;
    @FXML
    private Button import_takes;
    @FXML
    private Button lec_takes;

    /**
     * Initializes the controller class.
     */
    database db1 = new database();
    @FXML
    private AnchorPane p1_takes_pane;
    @FXML
    private Button save_std_takes;
    @FXML
    private TableView table_std_takes;
    @FXML
    private AnchorPane p2_edit_takes;
    @FXML
    private Button can_2;
    @FXML
    private Button add_2;
    @FXML
    private TableView table_lec_takes;
    @FXML
    private TableColumn t2_takes;
    @FXML
    private TableColumn t2std_name;
    @FXML
    private ComboBox chose_lec;
    @FXML
    private AnchorPane take_pane;
    @FXML
    private AnchorPane p4_std_more;
    @FXML
    private Button can_21;
    @FXML
    private ListView liset;
    @FXML
    private AnchorPane p4_import_takes;
    @FXML
    private Button can_22;
    @FXML
    private Button import_file;
    @FXML
    private ComboBox chose_lec1;
    @FXML
    private Button chose_file;
    @FXML
    private TextField file_path;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        if (vtype == 0) {
            try {
                chose_council.setItems(FXCollections.observableArrayList(db1.all_councel_name()));
            } catch (SQLException ex) {
                Logger.getLogger(TakesController.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else if (vtype == 1) {
            try {
                chose_council.setItems(FXCollections.observableArrayList(db1.v_councel_name(user_name)));
            } catch (SQLException ex) {
                Logger.getLogger(LectureController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        t_lec_num.setCellValueFactory(new PropertyValueFactory("lec_num"));
        t_lec_topic.setCellValueFactory(new PropertyValueFactory("lec_name"));
        ttakes.setCellValueFactory(new PropertyValueFactory("ss"));

        t2std_name.setCellValueFactory(new PropertyValueFactory("Std_name"));
        t2_takes.setCellValueFactory(new PropertyValueFactory("Ss"));

    }

    @FXML
    private void cancel_2() {

        table_lec_takes.setDisable(true);
        chose_std_name.getSelectionModel().clearSelection();
        chose_lec.getSelectionModel().clearSelection();
        p1_takes_pane.toFront();
    }

    @FXML
    private void chose_std_name(ActionEvent event) throws SQLException {
        table_std_takes.setDisable(false);
        if (chose_std_name.getValue() != null) {
            table_std_takes.setItems(FXCollections.observableArrayList(db1.std_takes_lec(chose_council.getValue().toString(), chose_std_name.getValue().toString())));
        }
    }

    @FXML
    private void chose_council(ActionEvent event) {
        std_takes.setDisable(false);
        std_more.setDisable(false);
        lec_takes.setDisable(false);
        import_takes.setDisable(false);
    }

    @FXML
    private void std_takes(ActionEvent event) throws SQLException {
        table_std_takes.setDisable(true);
        chose_std_name.setItems(FXCollections.observableArrayList(db1.all__council_student(chose_council.getValue().toString())));
        p2_std_takes.toFront();

    }

    @FXML
    private void std_more(ActionEvent event) throws SQLException {
        liset.setItems(FXCollections.observableArrayList(db1.std_more(chose_council.getValue().toString())));
        p4_std_more.toFront();
    }

    @FXML
    private void import_takes(ActionEvent event) throws SQLException {
        table_lec_takes.setDisable(true);
        chose_lec1.setItems(FXCollections.observableArrayList(db1.all__council_lecture(chose_council.getValue().toString())));
        p4_import_takes.toFront();

    }

    @FXML
    private void lec_takes(ActionEvent event) throws SQLException {
        table_lec_takes.setDisable(true);
        chose_lec.setItems(FXCollections.observableArrayList(db1.all__council_lecture(chose_council.getValue().toString())));
        p2_edit_takes.toFront();
    }

    ArrayList<String> takes = new ArrayList();
    boolean ed = false;

    @FXML
    private void save_std_takes(ActionEvent event) throws SQLException {

        ObservableList<alldata> qq = table_std_takes.getItems();
        for (int i = 0; i < table_std_takes.getItems().size(); i++) {

            if (qq.get(i).getChecked() == 1) {
                if (takes.indexOf(qq.get(i).getLec_num()) == -1) {
                    takes.add(qq.get(i).getLec_num());
                    ed = true;
                    //System.out.println(qq.get(i).getStd_name()+" "+qq.get(i).getChecked());
                }
            } else if (qq.get(i).getChecked() == 0) {
                if (takes.indexOf(qq.get(i).getLec_num()) != -1) {
                    takes.remove(qq.get(i).getLec_num());
                    ed = true;
                    //System.out.println(qq.get(i).getStd_name()+" "+qq.get(i).getChecked());
                }
            }

        }
        if (ed) {
            db1.delete_takes2(chose_council.getValue().toString(), chose_std_name.getValue().toString());
            for (int i = 0; i < takes.size(); i++) {
                db1.add_takes(chose_std_name.getValue().toString(), chose_council.getValue().toString(), Integer.parseInt(takes.get(i)));
            }
        }

        cancel_2();

    }

    ArrayList<String> takes2 = new ArrayList();
    boolean ed2 = false;

    @FXML
    private void add_2(ActionEvent event) throws SQLException {
        ObservableList<alldata> qq = table_lec_takes.getItems();
        for (int i = 0; i < table_lec_takes.getItems().size(); i++) {

            if (qq.get(i).getChecked() == 1) {
                if (takes2.indexOf(qq.get(i).getStd_name()) == -1) {
                    takes2.add(qq.get(i).getStd_name());
                    ed2 = true;
                    //System.out.println(qq.get(i).getStd_name()+" "+qq.get(i).getChecked());
                }
            } else if (qq.get(i).getChecked() == 0) {
                if (takes2.indexOf(qq.get(i).getStd_name()) != -1) {
                    takes2.remove(qq.get(i).getStd_name());
                    ed2 = true;

                    //System.out.println(qq.get(i).getStd_name()+" "+qq.get(i).getChecked());
                }
            }

        }
        if (ed2) {
            db1.delete_takes(chose_council.getValue().toString(), leclec);
            for (int i = 0; i < takes2.size(); i++) {
                db1.add_takes(takes2.get(i), chose_council.getValue().toString(), leclec);
            }
        }
        cancel_2();
    }

    int leclec = -1;
    String lec;

    @FXML
    private void chose_lec(ActionEvent event) throws SQLException {
        if (chose_lec.getValue() != null) {
            table_lec_takes.setDisable(false);
            lec = chose_lec.getValue().toString();
            String[] x = lec.split("  .");
            leclec = Integer.parseInt(x[x.length - 1]);
            table_lec_takes.setItems(FXCollections.observableArrayList(db1.lec_takes(chose_council.getValue().toString(), Integer.parseInt(x[x.length - 1]))));

        }

    }
    int leclec2 = -1;
    String lec2;

    @FXML
    private void import_file(ActionEvent event) throws FileNotFoundException, IOException, SQLException {
        db1.lec_takes(council_name, leclec);
        FileInputStream fi = new FileInputStream(file_path.getText());
        Workbook wb = WorkbookFactory.create(fi);
        Sheet sh = wb.getSheet("Sheet1");
        int num_of_rows = sh.getLastRowNum();
        lec2 = chose_lec1.getValue().toString();
        String[] x = lec2.split("  .");
        leclec2 = Integer.parseInt(x[x.length - 1]);
        ArrayList<alldata> x1 = db1.lec_takes(chose_council.getValue().toString(), leclec2);
        ArrayList<String> x2 = new ArrayList();
        for (int i = 0; i < x1.size(); i++) {
            if (x1.get(i).getChecked() == 1) {
                System.out.println(x1.get(i).getStd_name());
                x2.add(x1.get(i).getStd_name());
            }

        }

        for (int i = 0; i <= num_of_rows; i++) {

            if (x2.indexOf(sh.getRow(i).getCell(0).toString()) == -1) {
                db1.add_takes(sh.getRow(i).getCell(0).toString(), chose_council.getValue().toString(), leclec2);
            }

        }
        fi.close();
        import_file.setDisable(true);
        p1_takes_pane.toFront();
    }

    @FXML
    private void chose_file(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Resource File");
        fileChooser.getExtensionFilters().addAll(
                new ExtensionFilter("Excel Files", "*.xls"),
                new ExtensionFilter("Excel Files", "*.xlsx"),
                new ExtensionFilter("All Files", "*.*")
        );

        File selectedFile = fileChooser.showOpenDialog(p4_import_takes.getScene().getWindow());

        if (selectedFile != null) {
            file_path.setText(selectedFile.getPath());
        }
        set_v();

    }

    private void set_v() {
        if (!file_path.getText().isEmpty()) {
            import_file.setDisable(false);

        } else {
            import_file.setDisable(true);
        }

    }

    private void set_v2() {
        if (chose_lec1.getValue() != null) {
            chose_file.setDisable(false);

        } else {
            import_file.setDisable(true);
        }

    }
    int leclec3 = -1;
    String lec3;

    @FXML
    private void chose_lec2(ActionEvent event) {
        set_v2();
        if (chose_lec1.getValue() != null) {

            lec3 = chose_lec1.getValue().toString();
            String[] x = lec3.split("  .");
            leclec3 = Integer.parseInt(x[x.length - 1]);
            try {
                table_lec_takes.setItems(FXCollections.observableArrayList(db1.lec_takes(chose_council.getValue().toString(), Integer.parseInt(x[x.length - 1]))));
            } catch (SQLException ex) {
                Logger.getLogger(TakesController.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }

    @FXML
    private void export(ActionEvent event) throws FileNotFoundException, IOException, SQLException {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Resource File");
        fileChooser.getExtensionFilters().addAll(
                new ExtensionFilter("Excel Files", "*.xls")
        );

        File selectedFile = fileChooser.showSaveDialog(p4_import_takes.getScene().getWindow());

        if (selectedFile != null) {
            HSSFWorkbook wb = new HSSFWorkbook();
            HSSFSheet sh = wb.createSheet("Sheet1");
            int num_of_rows = sh.getLastRowNum();
            ArrayList<String> std_m=db1.std_more(chose_council.getValue().toString());
            for (int i =0; i < std_m.size(); i++) {
            HSSFRow r = sh.createRow(i);
            HSSFCell c = r.createCell(0);
            c.setCellValue(std_m.get(i));
            }
           
            
            FileOutputStream fo = new FileOutputStream(new File(selectedFile.getPath()));
            wb.write(fo);
            fo.flush();
            fo.close();
        }
    }

}
