/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;

/**
 * FXML Controller class
 *
 * @author Mohammed
 */
public class V_add_new_studentController implements Initializable {
    
    static String council_name;

    @FXML
    private AnchorPane add_student_pane;
    @FXML
    private AnchorPane p2_add_phone;
    @FXML
    private Button cancel_2;
    @FXML
    private Button add_new_phone_submit;
    @FXML
    private TextField tf_new_phone;
    @FXML
    private AnchorPane p1_add_std;
    @FXML
    private Button close;
    @FXML
    private HBox hbox2;
    @FXML
    private TextField t4;
    @FXML
    private ListView list2;
    @FXML
    private TextField t3;
    @FXML
    private TextField t1;
    @FXML
    private HBox hbox1;
    @FXML
    private Button add;
    @FXML
    private Button add_phone_number;
    @FXML
    private Label labelcheck;

    /**
     * Initializes the controller class.
     */
    database db1=new database();
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        t4.setText(council_name);


    }    

   @FXML
    private void close() throws SQLException {
        AnchorPane x = (AnchorPane) add_student_pane.getParent();
        for (int i = 0; i < 4; i++) {
            x.getChildren().get(i).setDisable(false);
        }
        x.getChildren().remove(4);
        AnchorPane z = (AnchorPane) x.getChildren().get(3);
        TableView tb = (TableView) z.getChildren().get(0);
        tb.setItems(FXCollections.observableArrayList(db1.v_council_student("%",council_name)));
    }

    @FXML
    private void setvisable() {
        String x[]=t1.getText().split("\\s+");
        if (x.length==4&&!t1.getText().isEmpty() && !t3.getText().isEmpty()) {
            add.setDisable(false);
            t1.setStyle("-fx-border-color:null");
            labelcheck.setDisable(true);
            labelcheck.setVisible(false);
        } else {
            if(x.length!=4){
            t1.setStyle("-fx-border-color:red");
            labelcheck.setDisable(false);
            labelcheck.setVisible(true);}
            else{
                t1.setStyle("-fx-border-color:null");
            labelcheck.setDisable(true);
            labelcheck.setVisible(false);}
            add.setDisable(true);
        }
    }

    @FXML
    private void chcek(KeyEvent event) {
    }

    @FXML
    private void add(ActionEvent event) throws SQLException {
         ArrayList<alldata> all_std=db1.allstudent("%");
         ArrayList<String> all_std_name=new ArrayList();
         for (int i = 0; i < all_std.size(); i++) {
           all_std_name.add(all_std.get(i).getStd_name());
            
        }
        
        if (all_std_name.indexOf(t1.getText())==-1) {
                    db1.add_student(t1.getText(), t3.getText());

        }
        
            
        db1.add_student_enrollment(t1.getText(),council_name);
            

        
        if (edited_new_phone) {
            

            for (int i = 0; i < new_phones.size(); i++) {
                db1.add_new_std_phone(t1.getText(), new_phones.get(i));
            }

        }
        close();
    }

    @FXML
    private void add_phone_number(ActionEvent event) {
        p1_add_std.setDisable(true);
        p2_add_phone.setDisable(false);
        p2_add_phone.toFront();
        tf_new_phone.clear();
    }

    @FXML
    private void cancel_2() {

        p2_add_phone.setDisable(true);
        p1_add_std.setDisable(false);
        p1_add_std.toFront();
    }

    ArrayList<String> new_phones = new ArrayList();
    boolean edited_new_phone = false;

    @FXML
    private void add_new_phone_submit(ActionEvent event) throws SQLException {
        if (!edited_new_phone && new_phones.isEmpty()) {
            ArrayList<String> data_ph = db1.get_std_phones(t1.getText());
            for (String phone : data_ph) {
                new_phones.add(phone);
                
            }
        }

        new_phones.add(tf_new_phone.getText());
        edited_new_phone = true;

        list2.setItems(FXCollections.observableArrayList(new_phones));
        cancel_2();

    }




}
