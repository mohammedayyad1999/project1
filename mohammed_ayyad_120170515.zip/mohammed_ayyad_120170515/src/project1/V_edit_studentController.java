/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;

/**
 * FXML Controller class
 *
 * @author Mohammed
 */
public class V_edit_studentController implements Initializable {
    static String std_name = "";
    static String std_area = "";
    static String council_name = "";
    static int selected;
    boolean edited_new_phone=false;
    boolean edited_new_phone2=false;
    @FXML
    private AnchorPane edit_student_pane;
    @FXML
    private AnchorPane p3_add_phone;
    @FXML
    private Button cancel_2;
    @FXML
    private Button add_new_phone_submit;
    @FXML
    private TextField tf_new_phone;
    @FXML
    private AnchorPane p1_std_edit;
    @FXML
    private Button save;
    @FXML
    private Button close;
    @FXML
    private HBox hbox2;
    @FXML
    private TextField t3;
    @FXML
    private ComboBox combo_phone_num;
    @FXML
    private TextField t1;
    @FXML
    private HBox hbox1;
    @FXML
    private Button add_new_phone;
    @FXML
    private Button remove_selected_phone;

    /**
     * Initializes the controller class.
     */
      database db1 = new database();
    @FXML
    private TextField t4;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        t1.setText(std_name);
        t3.setText(std_area);
        
       
        
        if(!edited_new_phone&&new_phones.isEmpty()){
            try {
                ArrayList<String> data_ph = db1.get_std_phones(t1.getText());
                for (String phone : data_ph) {
                    new_phones.add(phone);
                    
                    
                edited_new_phone=true;
                }
            } catch (SQLException ex) {
                Logger.getLogger(EditStudentController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        combo_phone_num.setItems(FXCollections.observableArrayList(new_phones));
        t4.setText(council_name);
    }

    @FXML
    private void save(ActionEvent event) throws SQLException {
        if (!t3.getText().equals(std_area)) {
            db1.update_student_area(t1.getText(), t3.getText());
            std_area = t3.getText();
            
            setvisable();
        }
        
        if (edited_new_phone) {
            db1.remove__all_std_phone(t1.getText());
            for (int i = 0; i < new_phones.size(); i++) {
                db1.add_new_std_phone(t1.getText(), new_phones.get(i));
                
            }
               setvisable();
}

close();
        
         

    }

    @FXML
    private void close() throws SQLException {
        AnchorPane x = (AnchorPane) edit_student_pane.getParent();
        for (int i = 0; i < 4; i++) {
            x.getChildren().get(i).setDisable(false);
        }
        x.getChildren().remove(4);
        AnchorPane z = (AnchorPane) x.getChildren().get(3);
        TableView tb = (TableView) z.getChildren().get(0);
        tb.setItems(FXCollections.observableArrayList(db1.v_council_student("%",council_name)));
        tb.getSelectionModel().select(selected);
    }

    @FXML
    private void setvisable() {
        if (!t3.getText().equals(std_area)) {
            save.setDisable(false);
        } else {
            save.setDisable(true);
        }

    }

     @FXML
    private void add_new_phone(ActionEvent event) {
        p1_std_edit.setDisable(true);
        p3_add_phone.setDisable(false);
        p3_add_phone.toFront();
        tf_new_phone.clear();
   }

    @FXML
    private void remove_selected_phone(ActionEvent event) throws SQLException {

if(!edited_new_phone&&new_phones.isEmpty()){
            ArrayList<String> data_ph = db1.get_std_phones(t1.getText());
            for (String phone : data_ph) {
            new_phones.add(phone);
            edited_new_phone=true;
        }}
new_phones.remove(combo_phone_num.getValue().toString());
 combo_phone_num.setItems(FXCollections.observableArrayList(new_phones));
 save.setDisable(false);
 remove_selected_phone.setDisable(true);
    }

    @FXML
    private void cancel_2() {
       
        p3_add_phone.setDisable(true);
        p1_std_edit.setDisable(false);
        p1_std_edit.toFront();
    }

    ArrayList<String> new_phones = new ArrayList();
    

    @FXML
    private void add_new_phone_submit(ActionEvent event) throws SQLException {

      
        if(!edited_new_phone&&new_phones.isEmpty()){
            ArrayList<String> data_ph = db1.get_std_phones(t1.getText());
            for (String phone : data_ph) {
            new_phones.add(phone);
            
            
        }
            edited_new_phone=true;
        }
        
        new_phones.add(tf_new_phone.getText());
       
        combo_phone_num.setItems(FXCollections.observableArrayList(new_phones));
        edited_new_phone2=true;
        save.setDisable(false);
        cancel_2();

    }

    

    @FXML
    private void set_remove_phone_enable(ActionEvent event) {
        remove_selected_phone.setDisable(false);

    }
    
    
   

   
    

}
