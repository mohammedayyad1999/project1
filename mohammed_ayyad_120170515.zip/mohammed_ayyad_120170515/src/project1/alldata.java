/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;

import javafx.scene.control.CheckBox;

/**
 *
 * @author Mohammed
 */
public class alldata {

    /**
     * @return the user_name
     */


    private String council_nsme;
    private String instructor;
    private String book;
    private String topic;
    private String place;
    private String std_count;
    private String lec_count;
    private String std_name;
    private String std_phone;
    private String std_area;
    private String std_councel_count;

    private String std_councel;
    private int checked;
    private CheckBox ss;

    private String lec_name;
    private String lec_num;
    private String lec_plase;
    private String takes_num;
    
    private String user_name;
    private String password;
    private String type;
    private String user_council;
    
     public alldata(int x,String a, String b, String c,String d) {
     this.user_name=a;
     this.password=b;
     this.type=c;
     this.user_council=d;
     
     }
    

    public alldata(int a, String b, int c) {
        this.lec_num=""+a;
        this.lec_name=b;
        this.checked=c;
        if (c == 0) {
            CheckBox z = new CheckBox();
            z.setSelected(false);
            z.setOnAction((ActionEvent) -> {
                if (z.isSelected()) {
                    checked = 1;
                } else {
                    checked = 0;
                }
            });
            this.ss = z;
        } else if (c == 1) {
            CheckBox z = new CheckBox();
            z.setSelected(true);
            z.setOnAction((ActionEvent) -> {
                if (z.isSelected()) {
                    checked = 1;
                } else {
                    checked = 0;
                }
            });
            this.ss = z;
        }

    }

    public alldata(String a, String b, String c, String d, String x) {
        lec_num = a;
        lec_name = b;
        lec_plase = c;
        takes_num = d;
    }

    public alldata(String a, String b, int c) {
        this.std_name = a;
        this.std_councel = b;
        this.checked = c;
        if (c == 0) {
            CheckBox z = new CheckBox();
            z.setSelected(false);
            z.setOnAction((ActionEvent) -> {
                if (z.isSelected()) {
                    checked = 1;
                } else {
                    checked = 0;
                }
            });
            this.ss = z;
        } else if (c == 1) {
            CheckBox z = new CheckBox();
            z.setSelected(true);
            z.setOnAction((ActionEvent) -> {
                if (z.isSelected()) {
                    checked = 1;
                } else {
                    checked = 0;
                }
            });
            this.ss = z;
        }
    }

    public alldata(String a, String b, String c, String d) {
        this.std_name = a;
        this.std_phone = b;
        this.std_area = c;
        this.std_councel_count = d;

    }

    public alldata(String a, String b, String c, String d, String e, String f, String g) {
        this.council_nsme = a;
        this.instructor = b;
        this.book = c;
        this.topic = d;
        this.place = e;
        this.std_count = f;
        this.lec_count = g;
    }

    /**
     * @return the council_nsme
     */
    public String getCouncil_nsme() {
        return council_nsme;
    }

    /**
     * @param council_nsme the council_nsme to set
     */
    public void setCouncil_nsme(String council_nsme) {
        this.council_nsme = council_nsme;
    }

    /**
     * @return the instructor
     */
    public String getInstructor() {
        return instructor;
    }

    /**
     * @param instructor the instructor to set
     */
    public void setInstructor(String instructor) {
        this.instructor = instructor;
    }

    /**
     * @return the book
     */
    public String getBook() {
        return book;
    }

    /**
     * @param book the book to set
     */
    public void setBook(String book) {
        this.book = book;
    }

    /**
     * @return the topic
     */
    public String getTopic() {
        return topic;
    }

    /**
     * @param topic the topic to set
     */
    public void setTopic(String topic) {
        this.topic = topic;
    }

    /**
     * @return the place
     */
    public String getPlace() {
        return place;
    }

    /**
     * @param place the place to set
     */
    public void setPlace(String place) {
        this.place = place;
    }

    /**
     * @return the std_count
     */
    public String getStd_count() {
        return std_count;
    }

    /**
     * @param std_count the std_count to set
     */
    public void setStd_count(String std_count) {
        this.std_count = std_count;
    }

    /**
     * @return the lec_count
     */
    public String getLec_count() {
        return lec_count;
    }

    /**
     * @param lec_count the lec_count to set
     */
    public void setLec_count(String lec_count) {
        this.lec_count = lec_count;

    }

    /**
     * @return the std_name
     */
    public String getStd_name() {
        return std_name;
    }

    /**
     * @param std_name the std_name to set
     */
    public void setStd_name(String std_name) {
        this.std_name = std_name;
    }

    /**
     * @return the std_phone
     */
    public String getStd_phone() {
        return std_phone;
    }

    /**
     * @param std_phone the std_phone to set
     */
    public void setStd_phone(String std_phone) {
        this.std_phone = std_phone;
    }

    /**
     * @return the std_area
     */
    public String getStd_area() {
        return std_area;
    }

    /**
     * @param std_area the std_area to set
     */
    public void setStd_area(String std_area) {
        this.std_area = std_area;
    }

    /**
     * @return the std_councel_count
     */
    public String getStd_councel_count() {
        return std_councel_count;
    }

    /**
     * @param std_councel_count the std_councel_count to set
     */
    public void setStd_councel_count(String std_councel_count) {
        this.std_councel_count = std_councel_count;
    }

    /**
     * @return the std_councel
     */
    public String getStd_councel() {
        return std_councel;
    }

    /**
     * @param std_councel the std_councel to set
     */
    public void setStd_councel(String std_councel) {
        this.std_councel = std_councel;
    }

    /**
     * @return the ss
     */
    public CheckBox getSs() {
        return ss;
    }

    /**
     * @param ss the ss to set
     */
    public void setSs(CheckBox ss) {
        this.ss = ss;
    }

    /**
     * @return the checked
     */
    public int getChecked() {
        return checked;
    }

    /**
     * @param checked the checked to set
     */
    public void setChecked(int checked) {
        this.checked = checked;
    }

    /**
     * @return the lec_name
     */
    public String getLec_name() {
        return lec_name;
    }

    /**
     * @param lec_name the lec_name to set
     */
    public void setLec_name(String lec_name) {
        this.lec_name = lec_name;
    }

    /**
     * @return the lec_num
     */
    public String getLec_num() {
        return lec_num;
    }

    /**
     * @param lec_num the lec_num to set
     */
    public void setLec_num(String lec_num) {
        this.lec_num = lec_num;
    }

    /**
     * @return the lec_plase
     */
    public String getLec_plase() {
        return lec_plase;
    }

    /**
     * @param lec_plase the lec_plase to set
     */
    public void setLec_plase(String lec_plase) {
        this.lec_plase = lec_plase;
    }

    /**
     * @return the takes_num
     */
    public String getTakes_num() {
        return takes_num;
    }

    /**
     * @param takes_num the takes_num to set
     */
    public void setTakes_num(String takes_num) {
        this.takes_num = takes_num;
    }
    
        public String getUser_name() {
        return user_name;
    }

    /**
     * @param user_name the user_name to set
     */
    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the user_council
     */
    public String getUser_council() {
        return user_council;
    }

    /**
     * @param user_council the user_council to set
     */
    public void setUser_council(String user_council) {
        this.user_council = user_council;
    }

}
