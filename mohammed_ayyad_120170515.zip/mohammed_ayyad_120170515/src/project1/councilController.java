/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author Mohammed
 */
public class councilController implements Initializable {

    @FXML
    private TableColumn tlec_count;
    @FXML
    private TableColumn tstd_count;
    @FXML
    private TableColumn tplace;
    @FXML
    private TableColumn  ttopic;
    @FXML
    private TableColumn tbook;
    @FXML
    private TableColumn tinstrucor;
    @FXML
    private TableColumn tcouncil;
    @FXML
    private TableView table;
    @FXML
    private AnchorPane council_pane;
    @FXML
    private TextField searchtext;
    @FXML
    private Button coun_setting;
    @FXML
    private Button add_council;
    @FXML
    private Button trash;

    /**
     * Initializes the controller class.
     */
    database db1=new database();
    @FXML
    private Button delete_council;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       
        
        tcouncil.setCellValueFactory(new PropertyValueFactory("Council_nsme"));
        tinstrucor.setCellValueFactory(new PropertyValueFactory("Instructor"));
        tbook.setCellValueFactory(new PropertyValueFactory("Book"));
        ttopic.setCellValueFactory(new PropertyValueFactory("Topic"));
        tplace.setCellValueFactory(new PropertyValueFactory("Place"));
        tstd_count.setCellValueFactory(new PropertyValueFactory("Std_count"));
        tlec_count.setCellValueFactory(new PropertyValueFactory("Lec_count"));
        try {
            table.setItems(FXCollections.observableArrayList(db1.allcouncil("%")));
        } catch (SQLException ex) {
            Logger.getLogger(councilController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    

    @FXML
    private void saerch() throws SQLException {
        if (searchtext.getText().trim().equals("")){
            table.setItems(FXCollections.observableArrayList(db1.allcouncil("%")));
        }
        else
            table.setItems(FXCollections.observableArrayList(db1.allcouncil("%"+searchtext.getText().trim()+"%")));
        setvisable();
    }
    
   

    @FXML
    private void council_setting() throws IOException {
        editCouncel$addCouncelController.type=1;
        AnchorPane anchorpane = (AnchorPane) council_pane.getParent();
        if(table.getSelectionModel().getSelectedIndex()!=-1){
       
        ObservableList<alldata> selected_row= table.getSelectionModel().getSelectedItems();
        System.out.println(selected_row.get(0).getCouncil_nsme()+"/n"+selected_row.get(0).getInstructor());
                ObservableList<alldata> sel_row = table.getSelectionModel().getSelectedItems();
                editCouncel$addCouncelController.coun_name = sel_row.get(0).getCouncil_nsme();
                editCouncel$addCouncelController.ins= sel_row.get(0).getInstructor();
                editCouncel$addCouncelController.book= sel_row.get(0).getBook();
                editCouncel$addCouncelController.topic= sel_row.get(0).getTopic();
                editCouncel$addCouncelController.place= sel_row.get(0).getPlace();
                try {
                    Parent zz = FXMLLoader.load(getClass().getResource("/project1/edit_councel&addcouncel.fxml"));
                    AnchorPane.setTopAnchor(zz,85.0);
                    AnchorPane.setBottomAnchor(zz,54.0);
                    AnchorPane.setLeftAnchor(zz,206.0);
                    AnchorPane.setRightAnchor(zz,134.0);
                    anchorpane.getChildren().add(zz);
                    
                } catch (IOException ex) {
                    Logger.getLogger(homeStartController.class.getName()).log(Level.SEVERE, null, ex);
                }
                for (int i = 0; i < 4; i++) {
                    anchorpane.getChildren().get(i).setDisable(true);
                }
    }
    }

    @FXML
    private void add_new_council() throws IOException, SQLException {
        editCouncel$addCouncelController.type=2;
        AnchorPane anchorpane = (AnchorPane) council_pane.getParent();
        Parent zz = FXMLLoader.load(getClass().getResource("/project1/edit_councel&addcouncel.fxml"));
                    AnchorPane.setTopAnchor(zz,85.0);
                    AnchorPane.setBottomAnchor(zz,54.0);
                    AnchorPane.setLeftAnchor(zz,206.0);
                    AnchorPane.setRightAnchor(zz,134.0);
                    anchorpane.getChildren().add(zz);
                    table.setItems(FXCollections.observableArrayList(db1.allcouncil("%")));
    }

    @FXML
    private void clear() throws SQLException {
        searchtext.setText("");
        saerch();
        setvisable();
    }

    @FXML
    private void setvisable() {
         if(table.getSelectionModel().getSelectedIndex()!=-1){
             coun_setting.setDisable(false);
             delete_council.setDisable(false);}
         
         else{
            coun_setting.setDisable(true);
         delete_council.setDisable(true);}
         }

    @FXML
    private void delete_selected_councel(ActionEvent event) throws SQLException {
        ButtonType ok = new ButtonType("حذف", ButtonBar.ButtonData.OK_DONE.LEFT);

        ButtonType close = new ButtonType("الغاء", ButtonBar.ButtonData.CANCEL_CLOSE.RIGHT);

        Alert alert = new Alert(Alert.AlertType.WARNING, "تحذير!!!\nسوف تقوم بحذف المجلس و جميع بياناته بلاضافة لسجالات الطلبة و سجل الانتماء لهذا المجلس", close, ok);
        alert.setTitle("Date format warning");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ok) {
          ObservableList<alldata> sel_row = table.getSelectionModel().getSelectedItems();
          db1.del_council(sel_row.get(0).getCouncil_nsme());
          saerch();
          delete_council.setDisable(true);
            setvisable();
        } else {
        }

         

    }

             
    
    
}
