/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;

import java.sql.*;
import java.sql.SQLException;
import java.util.ArrayList;
import javafx.collections.ObservableArray;
import org.postgresql.ds.PGSimpleDataSource;

/**
 *
 * @author Mohammed
 */
public class database {

    static Connection con = null;

    public void conncet() throws SQLException {
        PGSimpleDataSource src = new PGSimpleDataSource();
        src.setServerName("localhost");
        src.setDatabaseName("UNI1");
        src.setUser("postgres");
        src.setPassword("1234");
        con = (Connection) src.getConnection();
    }

    public void set_schema(String path) throws SQLException, Exception {
        String quary = "set search_path to '" + path + "'";
        Statement stmt = (Statement) con.createStatement();
        stmt.execute(quary);
        stmt.close();
    }

    public ArrayList<alldata> allcouncil(String s) throws SQLException {
        PreparedStatement stmt = con.prepareStatement("select c.council_name,c.instructor,c.book,c.topic,c.def_place,count(distinct s),count(distinct l.lec_number) from council c left join std_council s using (council_name) left join lecture l using (council_name) where council_name like ?\n"
                + "group by 1,2,3,4,5;");
        stmt.setString(1, s);
        ResultSet rs = stmt.executeQuery();
        ArrayList<alldata> a = new ArrayList();
        while (rs.next()) {
            a.add(new alldata(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7)));
        }

        rs.close();
        return a;

    }

    public void update_councel(String name, String instructor, String book, String topic, String place) throws SQLException {
        PreparedStatement stmt = con.prepareStatement("update council  set instructor=?,book=?,topic=?,def_place=? where council_name=?;");
        stmt.setString(1, instructor);
        stmt.setString(2, book);
        stmt.setString(3, topic);
        stmt.setString(4, place);
        stmt.setString(5, name);
        stmt.executeUpdate();
        stmt.close();

    }

    public void add_councel(String name, String instructor, String book, String topic, String place) throws SQLException {
        PreparedStatement stmt = con.prepareStatement("insert into council values( ?,?,?,?,?);");
        stmt.setString(1, name);
        stmt.setString(2, instructor);
        stmt.setString(3, topic);
        stmt.setString(4, book);
        stmt.setString(5, place);
        stmt.executeUpdate();
        stmt.close();

    }

    public void del_council(String council_name) throws SQLException {
        PreparedStatement stmt = con.prepareStatement("delete from std_council where council_name=?;delete from takes where council_name=?;delete from lecture where council_name=?;delete from council where council_name=?;");
        stmt.setString(1, council_name);
        stmt.setString(2, council_name);
        stmt.setString(3, council_name);
        stmt.setString(4, council_name);
        stmt.executeUpdate();
        stmt.close();
    }

    public ArrayList<alldata> allstudent(String s) throws SQLException {
        PreparedStatement stmt = con.prepareStatement("select distinct s.std_name, s.living_area from student s left join std_council sc using (std_name) where s.std_name like ? order by 1");
        stmt.setString(1, s);
        ResultSet rs = stmt.executeQuery();
        ArrayList<alldata> a = new ArrayList();
        while (rs.next()) {
            a.add(new alldata(rs.getString(1), all_std_phones(rs.getString(1)), rs.getString(2), all_std_council(rs.getString(1))));
        }

        rs.close();
        stmt.close();
        return a;

    }

    String all_std_phones(String name) throws SQLException {
        String sphones = "";
        PreparedStatement stmt = con.prepareStatement("select phone from student_phone where std_name=?");
        stmt.setString(1, name);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            sphones += rs.getString(1) + "\n";
        }
        rs.close();
        stmt.close();
        return sphones;
    }

    public String all_std_council(String name) throws SQLException {
        String coun = "";
        PreparedStatement stmt = con.prepareStatement("select distinct council_name from std_council where std_name =?");
        stmt.setString(1, name);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            coun += rs.getString(1) + "\n ";
        }
        rs.close();
        stmt.close();
        return coun;
    }

    public void delete_student(String name) throws SQLException {
        PreparedStatement stmt = con.prepareStatement("delete from std_council where std_name=?;\n"
                + "delete from takes where std_name=?; \n"
                + "delete from student_phone where std_name=?; \n"
                + "delete from student where std_name=?; ");

        stmt.setString(1, name);
        stmt.setString(2, name);
        stmt.setString(3, name);
        stmt.setString(4, name);

        stmt.executeUpdate();
        stmt.close();

    }

    public ArrayList<String> all_councel_name() throws SQLException {
        ArrayList<String> a = new ArrayList();
        PreparedStatement stmt = con.prepareStatement("select distinct council_name from council ;");
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            a.add(rs.getString(1));
        }
        stmt.close();
        rs.close();
        return a;
    }

    public void add_new_std_council(String name, String council) throws SQLException {
        PreparedStatement stmt = con.prepareStatement("insert into std_council values(?,?);");
        stmt.setString(1, name);
        stmt.setString(2, council);
        stmt.executeUpdate();

    }

    public void add_new_std_phone(String name, String phone) throws SQLException {
        PreparedStatement stmt = con.prepareStatement("insert into student_phone values(?,?);");
        stmt.setString(1, name);
        stmt.setString(2, phone);
        stmt.executeUpdate();
    }

    public ArrayList<String> get_std_phones(String name) throws SQLException {
        ArrayList<String> a = new ArrayList();
        PreparedStatement stmt = con.prepareStatement("select phone from student_phone where std_name= ?;");
        stmt.setString(1, name);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            a.add(rs.getString(1));
        }
        stmt.close();
        rs.close();
        return a;
    }
     public void remove_phone(String phone) throws SQLException {
        PreparedStatement stmt = con.prepareStatement("delete from student_phone where phone=?;");
        stmt.setString(1, phone);
        stmt.executeUpdate();
    }
     public void remove_student_enrollment(String name,String council) throws SQLException{
         PreparedStatement stmt=con.prepareStatement("delete from std_council where std_name= ? and council_name=?;");
         stmt.setString(1, name);
         stmt.setString(2, council);
         stmt.executeUpdate();
         stmt.close();
       
     }
     public void add_student_enrollment(String name,String council) throws SQLException{
         PreparedStatement stmt=con.prepareStatement("insert into std_council values(?,?);");
         stmt.setString(1, name);
         stmt.setString(2, council);
         stmt.executeUpdate();
         stmt.close();
       
     }
     public void update_student_area (String name,String area) throws SQLException{
         PreparedStatement stmt=con.prepareStatement("update student set living_area=? where std_name=?;");
         stmt.setString(1, area);
         stmt.setString(2, name);
         stmt.executeUpdate();
         stmt.close();
       
     }
     public void remove__all_std_phone(String name) throws SQLException {
        PreparedStatement stmt = con.prepareStatement("delete from student_phone where std_name=?;");
        stmt.setString(1, name);
        stmt.executeUpdate();
    }
     public ArrayList<String> all_std_council_arraylist(String name) throws SQLException {
        ArrayList<String> a = new ArrayList();
        PreparedStatement stmt = con.prepareStatement("select distinct council_name from std_council where std_name =?");
        stmt.setString(1, name);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            a.add(rs.getString(1));
        }
        rs.close();
        stmt.close();
        return a;
    }
     public void add_student(String name,String council) throws SQLException{
         PreparedStatement stmt=con.prepareStatement("insert into student values(?,?);");
         stmt.setString(1, name);
         stmt.setString(2, council);
         stmt.executeUpdate();
         stmt.close();
       
     }
     public ArrayList<alldata> council_student(String council,int check) throws SQLException {
        ArrayList<alldata> a = new ArrayList();
        PreparedStatement stmt = con.prepareStatement("select distinct std_name from std_council where council_name=? order by 1;");
        stmt.setString(1, council);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            a.add(new alldata(rs.getString(1),council,check));
        }
        rs.close();
        stmt.close();
        return a;
    }
     public ArrayList<alldata> council_lecture(String council,String topic) throws SQLException {
        ArrayList<alldata> a = new ArrayList();
        PreparedStatement stmt = con.prepareStatement("select lec_number,lec_topic,mosque,count(std_name) from lecture left join takes using(council_name,lec_number) where council_name=? and lec_topic like ? \n" +
                                                        "group by 1,2,3\n" +
                                                        "order by 1;");
        stmt.setString(1, council);
        stmt.setString(2, topic);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            a.add(new alldata(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),""));
        }
        rs.close();
        stmt.close();
        return a;
    }
     public void add_lecture(String council,String topic,String plase) throws SQLException{
         PreparedStatement stmt=con.prepareStatement("insert into lecture values (?,(select coalesce(max(lec_number),0)+1 from lecture where council_name=?),?,?);");
         stmt.setString(1, council);
         stmt.setString(2, council);
         stmt.setString(3,topic );
         stmt.setString(4, plase);
         stmt.executeUpdate();
         stmt.close();
       
     }
     
     public void add_takes(String std_name,String council_name,int lec_number) throws SQLException{
         PreparedStatement stmt=con.prepareStatement("insert into  takes values(?,?,?);");
         stmt.setString(1, std_name);
         stmt.setString(2, council_name);
         stmt.setInt(3,lec_number);
         stmt.executeUpdate();
         stmt.close();
       
     }
     public int lec_num(String council) throws SQLException {
        int a=-1;
        PreparedStatement stmt = con.prepareStatement("select coalesce(max(lec_number),0) from lecture where council_name=?");
        stmt.setString(1, council);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            a=rs.getInt(1);
        }
        rs.close();
        stmt.close();
        return a;
    }
     
     public ArrayList<alldata> lec_takes(String council,int lec_num) throws SQLException {
        ArrayList<String> a = new ArrayList();
        PreparedStatement stmt = con.prepareStatement("select std_name from takes where council_name=? and lec_number=?;");
        stmt.setString(1, council);
        stmt.setInt(2, lec_num);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            a.add(rs.getString(1));
        }
        
        ArrayList<alldata> b = new ArrayList();
        PreparedStatement stmt2 = con.prepareStatement("select distinct std_name from std_council where council_name=? order by 1;");
        stmt2.setString(1, council);
        ResultSet rs2 = stmt2.executeQuery();
        while (rs2.next()) {
            if(a.indexOf(rs2.getString(1))!=-1){
            b.add(new alldata(rs2.getString(1),council,1));
            //System.out.println(rs2.getString(1)+" 1");
            }
            else{
            b.add(new alldata(rs2.getString(1),council,0));
            //System.out.println(rs2.getString(1)+" 0");
            }
        }
        rs.close();
        stmt.close();
        
        rs2.close();
        stmt2.close();
        return b;
    }
     public void delete_takes(String council_name,int lec_number) throws SQLException{
         PreparedStatement stmt=con.prepareStatement("delete from takes where council_name= ? and lec_number= ? ;");
         stmt.setString(1, council_name);
         stmt.setInt(2,lec_number);
         stmt.executeUpdate();
         stmt.close();
       
     }
     public void update_lecture(String council_name,int lec_number,String topic,String place) throws SQLException{
         
         PreparedStatement stmt=con.prepareStatement("update lecture set lec_topic=?,mosque=? where council_name=? and lec_number=?;");
         stmt.setString(1, topic);
         stmt.setString(2, place);
         stmt.setString(3, council_name);
         stmt.setInt(4,lec_number);
         stmt.executeUpdate();
         stmt.close();
       
     }
     public void delete_lecture(String council_name,int lec_number) throws SQLException{
         PreparedStatement stmt=con.prepareStatement("delete from takes where council_name= ? and lec_number= ? ;"
                                                     + "delete from lecture where council_name=? and lec_number=?;");
         stmt.setString(1, council_name);
         stmt.setInt(2,lec_number);
         stmt.setString(3, council_name);
         stmt.setInt(4,lec_number);
         stmt.executeUpdate();
         stmt.close();
       
     }
     public ArrayList<alldata> std_takes_lec(String council,String std_name) throws SQLException {
        ArrayList<String> a = new ArrayList();
        PreparedStatement stmt = con.prepareStatement("select lec_number from takes where council_name=? and std_name=?;");
        stmt.setString(1, council);
        stmt.setString(2, std_name);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            a.add(rs.getString(1));
        }
        
        ArrayList<alldata> b = new ArrayList();
        PreparedStatement stmt2 = con.prepareStatement("select lec_number,lec_topic from lecture  where council_name=? ;");
        stmt2.setString(1, council);
        ResultSet rs2 = stmt2.executeQuery();
        while (rs2.next()) {
            if(a.indexOf(rs2.getString(1))!=-1){
            b.add(new alldata(rs2.getInt(1),rs2.getString(2),1));
            
            }
            else{
            b.add(new alldata(rs2.getInt(1),rs2.getString(2),0));
            //System.out.println(rs2.getString(1)+" 0");
            }
        }
        rs.close();
        stmt.close();
        
        rs2.close();
        stmt2.close();
        return b;
    }
     public ArrayList<String> all__council_student(String council) throws SQLException {
        ArrayList<String> a = new ArrayList();
        PreparedStatement stmt = con.prepareStatement("select distinct std_name from std_council where council_name=? order by 1;");
        stmt.setString(1, council);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            a.add(rs.getString(1));
        }
        rs.close();
        stmt.close();
        return a;
    }
     
     public void delete_takes2(String council_name,String name) throws SQLException{
         PreparedStatement stmt=con.prepareStatement("delete from takes where council_name= ? and std_name= ? ;");
         stmt.setString(1, council_name);
         stmt.setString(2,name);
         stmt.executeUpdate();
         stmt.close();
       
     }
     
     public ArrayList<String> all__council_lecture(String council) throws SQLException {
        ArrayList<String> a = new ArrayList();
        PreparedStatement stmt = con.prepareStatement("select concat(lec_topic,'  .',lec_number) from lecture  where council_name=? order by lec_number;");
        stmt.setString(1, council);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            a.add(rs.getString(1));
        }
        rs.close();
        stmt.close();
        return a;
    }
     
    public ArrayList<String> std_more(String council) throws SQLException {
        ArrayList<String> a = new ArrayList();
        PreparedStatement stmt = con.prepareStatement("select std_name from takes natural join lecture where council_name=?\n" +
"group by std_name\n" +
"having ((count(*)+0.0)/(select count(*)from lecture where council_name=?))>=0.9;");
        stmt.setString(1, council);
        stmt.setString(2, council);
        
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            a.add(rs.getString(1));
        }
        rs.close();
        stmt.close();
        return a;
    }
     
    
    public ArrayList<String> checkuser(String name) throws SQLException {
        ArrayList<String> a = new ArrayList();
        PreparedStatement stmt = con.prepareStatement("select * from users where users.user_name=?;");
        stmt.setString(1, name);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            a.add("1");
            a.add(rs.getString(1));
            a.add(rs.getString(2));
            a.add(rs.getString(3));
        }
        else
            a.add("0");
        rs.close();
        stmt.close();
        return a;
    }
    public ArrayList<alldata> v_council_student(String s,String council) throws SQLException {
       
        PreparedStatement stmt = con.prepareStatement("select distinct s.std_name, s.living_area from student s left join std_council sc using (std_name) where s.std_name like ? and council_name= ? order by 1");
        stmt.setString(1, s);
        stmt.setString(2, council);
        ResultSet rs = stmt.executeQuery();
        ArrayList<alldata> a = new ArrayList();
        while (rs.next()) {
            a.add(new alldata(rs.getString(1), all_std_phones(rs.getString(1)), rs.getString(2),""));
        }

        rs.close();
        stmt.close();
        return a;
        

    }
    
    public ArrayList<String> v_councel_name(String vname) throws SQLException {
        ArrayList<String> a = new ArrayList();
        PreparedStatement stmt = con.prepareStatement("select distinct council_name from user_council where user_name=? ;");
        stmt.setString(1, vname);
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            a.add(rs.getString(1));
        }
        stmt.close();
        rs.close();
        return a;
    }
    
    
     public ArrayList<alldata> all_users() throws SQLException {
       
        PreparedStatement stmt = con.prepareStatement("select user_name,user_password,user_type from users");
        ResultSet rs = stmt.executeQuery();
        ArrayList<alldata> a = new ArrayList();
        while (rs.next()) {
            String type="";
            if(rs.getString(3).equals("m"))
                type="مسؤول";
            else if(rs.getString(3).equals("v"))
                type="متطوع";
            
            String user_c="";
            ArrayList<String> x=all_users_council(rs.getString(1));
            for (int i = 0; i < x.size(); i++) {
                user_c+=x.get(i)+"\n ";
            }
            a.add(new alldata(0,rs.getString(1),rs.getString(2),type,user_c));
        }

        rs.close();
        stmt.close();
        return a;
     }
     public ArrayList<String> all_users_council(String name) throws SQLException {
       
        PreparedStatement stmt = con.prepareStatement("select council_name from user_council where user_name=?");
        stmt.setString(1, name);
        ResultSet rs = stmt.executeQuery();
        ArrayList<String> a = new ArrayList();
        while (rs.next()) {
            a.add(rs.getString(1));
        }

        rs.close();
        stmt.close();
        return a;
     }
     
     public void add_user(String name,String password,String ttype) throws SQLException{
         PreparedStatement stmt=con.prepareStatement("insert into users values(?,?,?);");
         stmt.setString(1, name);
         stmt.setString(2,password);
         String type="";
            if(ttype.equals("مسؤول"))
                type="m";
            else if(ttype.equals("متطوع"))
                type="v";
         stmt.setString(3,type);
         
         stmt.executeUpdate();
         stmt.close();
       
     }
     public void add_user_council(String name,String council) throws SQLException{
         PreparedStatement stmt=con.prepareStatement("insert into user_council values (?,?)");
         stmt.setString(1, name);
         stmt.setString(2,council);
         
         stmt.executeUpdate();
         stmt.close();
       
     }
        
     public void delete_user(String name) throws SQLException{
         PreparedStatement stmt=con.prepareStatement("delete from user_council  where user_name=?;\n" +
                                                        "delete from users where user_name=?;");
         stmt.setString(1, name);
         stmt.setString(2,name);
         
         stmt.executeUpdate();
         stmt.close();
       
     }
     
     

}
