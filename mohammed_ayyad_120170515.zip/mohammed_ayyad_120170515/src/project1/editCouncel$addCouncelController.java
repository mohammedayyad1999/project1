/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import static project1.EditStudentController.selected;

/**
 * FXML Controller class
 *
 * @author Mohammed
 */
public class editCouncel$addCouncelController implements Initializable {

    static String coun_name;
    static String ins;
    static String book;
    static String topic;
    static String place;

    @FXML
    private TextField t5;
    @FXML
    private TextField t4;
    @FXML
    private TextField t3;
    @FXML
    private TextField t2;
    @FXML
    private TextField t1;
    @FXML
    private Button save;
    @FXML
    private Button close;
    @FXML
    private Button rest;
    boolean deleted = false;
    boolean saved = false;
    static int type=0;

    /**
     * Initializes the controller class.
     */
    database db1 = new database();
    @FXML
    private AnchorPane edit_concil_pane;
    @FXML
    private Button add;

    @FXML
    private HBox hbox2;
    @FXML
    private HBox hbox1;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        if(type==1){
        t1.setText(this.coun_name);
        t2.setText(ins);
        t3.setText(book);
        t4.setText(topic);
        t5.setText(place);
        setvisable();}
        checktype();
    }
  

    @FXML
    private void setvisable() {

        String cinst = t2.getText();
        String cbook = t3.getText();
        String ctopic = t4.getText();
        String cplace = t5.getText();

        if (type==1){
            if(!deleted && (!cinst.equals(ins) || !cbook.equals(book)) || !ctopic.equals(topic) || !cplace.equals(place)) {

            rest.setDisable(false);
            save.setDisable(false);
            saved = false;}
            else{
                rest.setDisable(true);
            save.setDisable(true);
            saved = true;
            } 
                
        } 
        else if(type==2){
            if(!t1.getText().trim().equals("")&&!t2.getText().trim().equals("")&&!t3.getText().trim().equals("")&&!t4.getText().trim().equals("")&&!t5.getText().trim().equals(""))
                {
            add.setDisable(false);
        }
        else
                add.setDisable(true);
        
        }
       
        
        
    }

    @FXML
    private void save(ActionEvent event) throws SQLException{
        if (type==1){
        String cinst = t2.getText();
        String cbook = t3.getText();
        String ctopic = t4.getText();
        String cplace = t5.getText();
        System.out.println(cinst);
        db1.update_councel(coun_name, cinst, cbook, ctopic, cplace);
        ins = cinst;
        book = cbook;
        topic = ctopic;
        place = cplace;
        rest.setDisable(true);
        save.setDisable(true);
        saved = true;
        rest.setDisable(true);
        save.setDisable(true);  close();}
    }

    @FXML
    private void close() throws SQLException {
        AnchorPane x = (AnchorPane) edit_concil_pane.getParent();
        for (int i = 0; i < 4; i++) {
            x.getChildren().get(i).setDisable(false);
        }
        x.getChildren().remove(4);
        AnchorPane z = (AnchorPane) x.getChildren().get(3);
        TableView tb = (TableView) z.getChildren().get(0);
        tb.setItems(FXCollections.observableArrayList(db1.allcouncil("%")));
        tb.getSelectionModel().select(selected);
    }

    @FXML
    private void rest(ActionEvent event) {
        t2.setText(ins);
        t3.setText(book);
        t4.setText(topic);
        t5.setText(place);
        rest.setDisable(true);
        save.setDisable(true);
    }

    @FXML
    private void add(ActionEvent event) throws SQLException {
        db1.add_councel(t1.getText(), t2.getText(), t3.getText(), t4.getText(), t5.getText());
        add.setDisable(true);
        close();
    }
    void checktype(){
        if(type==1){
            save.setVisible(true);
            save.setDisable(true);
            add.setVisible(false);
            add.setDisable(true);
            t1.setEditable(false);
        }
        else if (type==2){
            add.setVisible(true);
            add.setDisable(true);
            save.setVisible(false);
            save.setDisable(true);
            t1.setEditable(true);
            rest.setVisible(false);
            AnchorPane.setRightAnchor(hbox1, 0.0);
            AnchorPane.setRightAnchor(hbox2, 0.0);
        }    
    }

}
