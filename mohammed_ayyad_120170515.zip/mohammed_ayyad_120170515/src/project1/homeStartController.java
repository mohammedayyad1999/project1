/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;


import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import static java.awt.Color.red;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.TranslateTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

/**
 * FXML Controller class
 *
 * @author Mohammed
 */
public class homeStartController implements Initializable {

    @FXML
    private AnchorPane anchorpane;

    @FXML
    private AnchorPane slidebane;
    @FXML
    private Button aaaa;
    @FXML
    private Button bbbb;
    @FXML
    private Button dddd;
    @FXML
    private Button cccc;

    @FXML
    private Button a;
    @FXML
    private Button b;
    @FXML
    private AnchorPane qq;
    @FXML
    private FontAwesomeIcon af1;
    @FXML
    private Label lable;
    @FXML
    private Button dddd1;
    @FXML
    private Button dddd11;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        try {
            // TODO
            Parent root = FXMLLoader.load(getClass().getResource("/project1/council.fxml"));
            AnchorPane.setRightAnchor(root, 0.0);
            AnchorPane.setBottomAnchor(root, 0.0);
            AnchorPane.setLeftAnchor(root, 175.0);
            anchorpane.getChildren().add(root);

        } catch (IOException ex) {
            Logger.getLogger(homeStartController.class.getName()).log(Level.SEVERE, null, ex);
        }
 aaaa.setStyle("-fx-background-color :  #0049a8");
    }

    @FXML
    private void aa(ActionEvent event) {
        TranslateTransition slide = new TranslateTransition();
        slide.setNode(slidebane);
        slide.setToX(-140);
        slide.play();

        TranslateTransition slide2 = new TranslateTransition();

        slide2.setNode(anchorpane.getChildren().get(3));
        slide2.setFromX(0);
        slide2.setToX(-140);
        slide2.play();
        TranslateTransition slide3 = new TranslateTransition();

        slide3.setNode(anchorpane.getChildren().get(2));

        slide3.setToX(0);
        slide3.play();

        b.setDisable(false);
        a.setDisable(true);

        AnchorPane.setRightAnchor(anchorpane.getChildren().get(3), -140.0);
        //AnchorPane.setLeftAnchor(anchorpane.getChildren().get(2),129.0);

    }

    @FXML
    private void bb(ActionEvent event) {
        TranslateTransition slide = new TranslateTransition();
        slide.setNode(slidebane);
        slide.setToX(0);
        slide.play();
        TranslateTransition slide2 = new TranslateTransition();
        slide2.setNode(anchorpane.getChildren().get(3));
        slide2.setToX(0);

        slide2.play();

        slide.setOnFinished((ActionEvent) -> {
            AnchorPane.setRightAnchor(anchorpane.getChildren().get(3), 0.0);

        });

        a.setDisable(false);
        b.setDisable(true);
    }

    @FXML
    private void aaaa(ActionEvent event) throws IOException {
        
        aaaa.setStyle("-fx-background-color :  #0049a8");
        cccc.setStyle("-fx-background-color :  #283251");
        dddd.setStyle("-fx-background-color :  #283251");
         bbbb.setStyle("-fx-background-color :  #283251");
         dddd1.setStyle("-fx-background-color :  #283251");
        
        if (!anchorpane.getChildren().get(3).getId().equals("council_pane")) {
            anchorpane.getChildren().remove(3);
            Parent root = FXMLLoader.load(getClass().getResource("/project1/council.fxml"));
            AnchorPane.setRightAnchor(root, 0.0);
            AnchorPane.setBottomAnchor(root, 0.0);
            AnchorPane.setLeftAnchor(root, 175.0);
            anchorpane.getChildren().add(root);
        }

    }

    @FXML
    private void bbbb(ActionEvent event) throws IOException {
        bbbb.setStyle("-fx-background-color :  #0049a8");
        aaaa.setStyle("-fx-background-color :  #283251");
        cccc.setStyle("-fx-background-color :  #283251");
        dddd.setStyle("-fx-background-color :  #283251");
        dddd1.setStyle("-fx-background-color :  #283251");
        if (!anchorpane.getChildren().get(3).getId().equals("student_pane")) {
            anchorpane.getChildren().remove(3);
            Parent root = FXMLLoader.load(getClass().getResource("/project1/student.fxml"));
            AnchorPane.setRightAnchor(root, 0.0);
            AnchorPane.setBottomAnchor(root, 0.0);
            AnchorPane.setLeftAnchor(root, 175.0);
            anchorpane.getChildren().add(root);
        }

    }

    @FXML
    private void cccc(ActionEvent event) throws IOException {
        bbbb.setStyle("-fx-background-color :  #283251");
        aaaa.setStyle("-fx-background-color :  #283251");
        cccc.setStyle("-fx-background-color :  #0049a8");
        dddd.setStyle("-fx-background-color :  #283251");
        dddd1.setStyle("-fx-background-color :  #283251");
        if (!anchorpane.getChildren().get(3).getId().equals("lec_pane")) {
            anchorpane.getChildren().remove(3);
            Parent root = FXMLLoader.load(getClass().getResource("/project1/lecture.fxml"));
            AnchorPane.setRightAnchor(root, 0.0);
            AnchorPane.setBottomAnchor(root, 0.0);
            AnchorPane.setLeftAnchor(root, 175.0);
            anchorpane.getChildren().add(root);
        }
    }
    @FXML
    private void dddd(ActionEvent event) throws IOException {
        bbbb.setStyle("-fx-background-color :  #283251");
        aaaa.setStyle("-fx-background-color :  #283251");
        cccc.setStyle("-fx-background-color :  #283251");
        dddd.setStyle("-fx-background-color :  #0049a8");
        dddd1.setStyle("-fx-background-color :  #283251");
        if (!anchorpane.getChildren().get(3).getId().equals("take_pane")) {
            anchorpane.getChildren().remove(3);
            Parent root = FXMLLoader.load(getClass().getResource("/project1/takes.fxml"));
            AnchorPane.setRightAnchor(root, 0.0);
            AnchorPane.setBottomAnchor(root, 0.0);
            AnchorPane.setLeftAnchor(root, 175.0);
            anchorpane.getChildren().add(root);
    }
    }

    @FXML
    private void eeee(ActionEvent event) throws IOException {
        bbbb.setStyle("-fx-background-color :  #283251");
        aaaa.setStyle("-fx-background-color :  #283251");
        cccc.setStyle("-fx-background-color :  #283251");
        dddd.setStyle("-fx-background-color :  #283251");
        dddd1.setStyle("-fx-background-color :  #0049a8");
        if (!anchorpane.getChildren().get(3).getId().equals("p1")) {
            anchorpane.getChildren().remove(3);
            Parent root = FXMLLoader.load(getClass().getResource("/project1/accounts.fxml"));
            AnchorPane.setRightAnchor(root, 0.0);
            AnchorPane.setBottomAnchor(root, 0.0);
            AnchorPane.setLeftAnchor(root, 175.0);
            anchorpane.getChildren().add(root);
    }
    }

    @FXML
    private void log_page(ActionEvent event) throws IOException {
        Parent fxmlLoader = FXMLLoader.load(getClass().getResource("/project1/login.fxml"));
            Scene scene = new Scene(fxmlLoader);
            Stage stage = new Stage();
            stage.setTitle("");
            stage.setScene(scene);
            stage.initStyle(StageStyle.UNDECORATED);
            stage.show();
            anchorpane.getScene().getWindow().hide();
    }


}
